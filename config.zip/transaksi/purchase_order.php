<?php
session_start();
include "../config/database.php";

// cek session admin
if(!isset($_SESSION['admin'])) {
    header("Location: ../login.php");
    exit;
}

$admin_id = $_SESSION['admin'];

// ambil username admin
$stmt = $conn->prepare("SELECT username FROM user_admin WHERE id=?");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();
$username = $admin ? $admin['username'] : "Admin";

// Proses tambah data
if(isset($_POST['tambah'])) {
    $so_id = $_POST['so_id'];
    $uraian_pekerjaan = $_POST['uraian_pekerjaan'];
    $periode = $_POST['periode'];
    $nomor_po = $_POST['nomor_po'];
    $tanggal_po = $_POST['tanggal_po'];
    $terima_po = isset($_POST['terima_po']) ? $_POST['terima_po'] : NULL;
    $nomor_berita_acara = $_POST['nomor_berita_acara'];
    $tanggal_ba = $_POST['tanggal_ba'];
    $terima_ba = isset($_POST['terima_ba']) ? $_POST['terima_ba'] : NULL;
    
$check = $conn->prepare("SELECT so_id FROM sales_order WHERE so_id = ?");
$check->bind_param("i", $so_id);
$check->execute();
$check_result = $check->get_result();

if($check_result->num_rows === 0) {
    $error = "SO ID tidak ditemukan di tabel sales_order!";
} else {
    $stmt = $conn->prepare("INSERT INTO purchase_order (so_id, uraian_pekerjaan, periode, nomor_po, tanggal_po, terima_po, nomor_berita_acara, tanggal_ba, terima_ba) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssssss", $so_id, $uraian_pekerjaan, $periode, $nomor_po, $tanggal_po, $terima_po, $nomor_berita_acara, $tanggal_ba, $terima_ba);

    if($stmt->execute()) {
        $success = "Data Purchase Order berhasil ditambahkan!";
    } else {
        $error = "Gagal menambahkan data: " . $stmt->error;
    }
}

}

// Proses edit data
if(isset($_POST['edit'])) {
    $po_id = $_POST['po_id'];
    $so_id = $_POST['so_id'];
    $uraian_pekerjaan = $_POST['uraian_pekerjaan'];
    $periode = $_POST['periode'];
    $nomor_po = $_POST['nomor_po'];
    $tanggal_po = $_POST['tanggal_po'];
    $terima_po = isset($_POST['terima_po']) ? $_POST['terima_po'] : NULL;
    $nomor_berita_acara = $_POST['nomor_berita_acara'];
    $tanggal_ba = $_POST['tanggal_ba'];
    $terima_ba = isset($_POST['terima_ba']) ? $_POST['terima_ba'] : NULL;
    
    $stmt = $conn->prepare("UPDATE purchase_order SET so_id=?, uraian_pekerjaan=?, periode=?, nomor_po=?, tanggal_po=?, terima_po=?, nomor_berita_acara=?, tanggal_ba=?, terima_ba=? WHERE po_id=?");
    $stmt->bind_param("issssssssi", $so_id, $uraian_pekerjaan, $periode, $nomor_po, $tanggal_po, $terima_po, $nomor_berita_acara, $tanggal_ba, $terima_ba, $po_id);
    
    if($stmt->execute()) {
        $success = "Data Purchase Order berhasil diupdate!";
    } else {
        $error = "Gagal mengupdate data: " . $conn->error;
    }
}if (isset($_GET['hapus'])) {
    $po_id = intval($_GET['hapus']);

    // 1️⃣ Cek apakah masih ada invoice terkait
    $checkInvoice = $conn->prepare("SELECT COUNT(*) FROM invoice WHERE po_id = ?");
    $checkInvoice->bind_param("i", $po_id);
    $checkInvoice->execute();
    $checkInvoice->bind_result($invoice_count);
    $checkInvoice->fetch();
    $checkInvoice->close();

    if ($invoice_count > 0) {
        // Jika masih ada invoice, tampilkan pesan
        $error = "Tidak bisa menghapus Purchase Order karena masih ada Invoice terkait. 
                  Silakan hapus dulu Invoice yang menggunakan PO ini.";
    } else {
        // 2️⃣ Cek apakah masih ada sales_order terkait
        $checkSO = $conn->prepare("SELECT COUNT(*) FROM sales_order WHERE po_id = ?");
        $checkSO->bind_param("i", $po_id);
        $checkSO->execute();
        $checkSO->bind_result($so_count);
        $checkSO->fetch();
        $checkSO->close();

        if ($so_count > 0) {
            $error = "Tidak bisa menghapus Purchase Order karena masih ada Sales Order terkait. 
                      Silakan hapus dulu Dropdown PO di Sales Order.";
        } else {
            // 3️⃣ Kalau tidak ada invoice dan tidak ada SO → hapus PO
            $stmt = $conn->prepare("DELETE FROM purchase_order WHERE po_id=?");
            $stmt->bind_param("i", $po_id);
            if ($stmt->execute()) {
                $success = "Purchase Order berhasil dihapus!";
            } else {
                $error = "Gagal menghapus data: " . $conn->error;
            }
        }
    }
}


// Ambil semua data purchase order dengan join sales order
$query = "SELECT po.*, so.nomor_so 
          FROM purchase_order po 
          LEFT JOIN sales_order so ON po.so_id = so.so_id 
          ORDER BY po.po_id ASC";
$result = $conn->query($query);

// Ambil data sales order untuk dropdown
$query_so = "SELECT so_id, nomor_so FROM sales_order ORDER BY so_id DESC";
$result_so = $conn->query($query_so);

// Ambil kapal aktif untuk uraian pekerjaan
$query_kapal = "SELECT kapal_id, nama_kapal FROM kapal WHERE status='AKTIF' ORDER BY nama_kapal ASC";
$result_kapal = $conn->query($query_kapal);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Purchase Order</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    background: linear-gradient(135deg, #3e4e92ff 0%, #764ba2 100%);
    min-height: 100vh;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* ===== Sidebar ===== */
.main-content {
    margin-left: 0px;
    transition: all 0.3s ease;
}

.sidebar {
    position: fixed;
    top: 0;
    left: -320px;
    width: 320px;
    height: 100%;
    background: linear-gradient(180deg, #1e3c72 0%, #2a5298 100%);
    color: #fff;
    overflow-y: auto;
    transition: all 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    z-index: 1050;
    box-shadow: 4px 0 20px rgba(0, 0, 0, 0.3);
}

.sidebar::-webkit-scrollbar {
    width: 8px;
}

.sidebar::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.1);
}

.sidebar::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.3);
    border-radius: 10px;
}

.sidebar.active { 
    left: 0;
    box-shadow: 4px 0 30px rgba(0, 0, 0, 0.5);
}

.sidebar-header { 
    padding: 25px 20px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-bottom: 2px solid rgba(255, 255, 255, 0.1);
}

.sidebar-header h3 {
    font-size: 22px;
    font-weight: 700;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    letter-spacing: 0.5px;
}

.sidebar-menu { 
    list-style: none;
    padding: 15px 0;
    margin: 0;
}

.sidebar-menu li { 
    list-style: none;
    padding: 5px 15px;
    margin: 3px 0;
}

.sidebar-menu li a {
    color: #fff;
    text-decoration: none;
    display: flex;
    align-items: center;
    padding: 14px 18px;
    border-radius: 12px;
    transition: all 0.3s ease;
    font-size: 15px;
    font-weight: 500;
    position: relative;
    overflow: hidden;
}

.sidebar-menu li a::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 4px;
    background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
    transform: scaleY(0);
    transition: transform 0.3s ease;
}

.sidebar-menu li a:hover {
    background: rgba(255, 255, 255, 0.15);
    padding-left: 28px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}

.sidebar-menu li a:hover::before {
    transform: scaleY(1);
}

.sidebar-menu li a i {
    margin-right: 12px;
    font-size: 18px;
    width: 25px;
    text-align: center;
}

/* ===== Hamburger ===== */
.hamburger-btn {
    position: fixed;
    top: 10px;
    left: 18px;
    z-index: 1100;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border: none;
    color: #fff;
    padding: 12px 16px;
    font-size: 22px;
    cursor: pointer;
    border-radius: 12px;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
}

.hamburger-btn:hover {
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.4);
}

.hamburger-btn.shifted { 
    left: 335px;
}

/* ===== Overlay ===== */
#overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(3px);
    display: none;
    z-index: 1040;
    transition: all 0.3s ease;
}

#overlay.active { display: block; }

/* ===== Dropdown custom ===== */
.submenu { 
    display: none;
    padding-left: 20px;
    list-style: none;
    margin-top: 5px;
}

.submenu.active { 
    display: block !important;
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.submenu li a {
    padding: 10px 18px;
    font-size: 14px;
    background: rgba(255, 255, 255, 0.05);
    margin: 3px 0;
}

.arrow { 
    float: right;
    transition: transform 0.3s ease;
    font-size: 12px;
}

.arrow::before { 
    font-size: 11px;
}

.dropdown-toggle.active .arrow {
    transform: rotate(180deg);
}

.dropdown-toggle::after {
    display: none;
}

/* ===== Header ===== */
.header {
    position: sticky;
    top: 0;
    left: 0;
    right: 0;
    height: 80px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 30px;
    z-index: 1030;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
    backdrop-filter: blur(10px);
}

.header .title { 
    margin-left: 50px;
    font-size: 24px;
    font-weight: 700;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    letter-spacing: 0.5px;
}

.header .user-info { 
    font-size: 15px;
    display: flex;
    align-items: center;
    gap: 15px;
    font-weight: 500;
}

.header .user-info .username {
    padding: 8px 18px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 20px;
    backdrop-filter: blur(10px);
}

.header .user-info a.logout-btn {
    background: linear-gradient(135deg, #ff416c, #ff4b2b);
    color: #fff;
    padding: 10px 24px;
    border-radius: 25px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(52, 11, 21, 0.4);
    display: inline-block;
}

.header .user-info a.logout-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(255, 65, 108, 0.5);
    filter: brightness(1.1);
}

/* ===== Main Content ===== */
.container-fluid {
    padding: 30px;
}

/* ===== Alert Styles ===== */
.alert {
    border-radius: 12px;
    border: none;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    animation: slideInDown 0.4s ease;
}

@keyframes slideInDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* ===== Card Styles ===== */
.card {
    border: none;
    border-radius: 18px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    background: rgba(255, 255, 255, 0.98);
    backdrop-filter: blur(10px);
    animation: fadeInUp 0.5s ease;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.card-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    border: none;
    border-radius: 18px 18px 0 0 !important;
    padding: 20px 25px;
}

.card-header h5 {
    margin: 0;
    font-weight: 700;
    font-size: 20px;
    text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2);
}

.card-body {
    padding: 25px;
}

/* ===== Button Styles ===== */
.btn {
    border-radius: 10px;
    padding: 8px 20px;
    font-weight: 600;
    transition: all 0.3s ease;
    border: none;
}

.btn-light {
    background: rgba(255, 255, 255, 0.3);
    color: #fff;
    border: 2px solid rgba(255, 255, 255, 0.5);
    backdrop-filter: blur(5px);
}

.btn-light:hover {
    background: rgba(255, 255, 255, 1);
    color: #667eea;
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}

.btn-success {
    background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
    color: #fff;
}

.btn-success:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(17, 153, 142, 0.4);
    filter: brightness(1.1);
}

.btn-warning {
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    color: #fff;
}

.btn-warning:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(245, 87, 108, 0.4);
    filter: brightness(1.1);
}

.btn-danger {
    background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%);
    color: #fff;
}

.btn-danger:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(255, 65, 108, 0.4);
    filter: brightness(1.1);
}

.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
    filter: brightness(1.1);
}

.btn-info {
    background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
    color: #fff;
}

.btn-info:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(79, 172, 254, 0.4);
    filter: brightness(1.1);
}

.btn-action {
    margin: 0 3px;
}

/* ===== Table Styles ===== */
.table-responsive {
    border-radius: 12px;
    overflow-x: auto;
    overflow-y: visible;
    font-size: 0.85rem;
    -webkit-overflow-scrolling: touch;
}

.table-responsive::-webkit-scrollbar {
    height: 10px;
}

.table-responsive::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 10px;
}

.table-responsive::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 10px;
}

.table-responsive::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
}

.table {
    margin: 0;
}

.table thead th {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    font-weight: 600;
    border: none;
    padding: 12px 8px;
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.5px;
}

.table tbody tr {
    transition: all 0.3s ease;
}

.table tbody tr:hover {
    background: rgba(102, 126, 234, 0.1);
    transform: scale(1.005);
}

.table tbody td {
    padding: 10px 8px;
    vertical-align: middle;
    font-size: 0.85rem;
}

/* ===== Badge Styles ===== */
.badge {
    padding: 6px 12px;
    border-radius: 20px;
    font-weight: 600;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.route-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 0.75rem;
    font-weight: 600;
}

.route-from {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
}

.route-to {
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    color: #fff;
}

/* ===== Modal Styles ===== */
.modal-content {
    border: none;
    border-radius: 18px;
    box-shadow: 0 15px 50px rgba(0, 0, 0, 0.3);
}

.modal-header {
    border-radius: 18px 18px 0 0;
    border-bottom: none;
    padding: 20px 25px;
}

.modal-body {
    padding: 25px;
}

.modal-footer {
    border-top: none;
    padding: 15px 25px 20px;
}

.form-label {
    font-weight: 600;
    color: #2a5298;
    margin-bottom: 8px;
    font-size: 0.9rem;
}

.form-control, .form-select {
    border: 2px solid #e0e6ed;
    border-radius: 10px;
    padding: 10px 15px;
    transition: all 0.3s ease;
    font-size: 0.9rem;
}

.form-control:focus, .form-select:focus {
    border-color: #667eea;
    box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
}

/* ===== Select2 Custom ===== */
.select2-container--default .select2-selection--single {
    border: 2px solid #e0e6ed;
    border-radius: 10px;
    height: 42px;
    padding: 6px 15px;
}

.select2-container--default .select2-selection--single:focus {
    border-color: #667eea;
}

/* ===== DataTables Custom ===== */
.dataTables_wrapper .dataTables_length select,
.dataTables_wrapper .dataTables_filter input {
    border: 2px solid #e0e6ed;
    border-radius: 8px;
    padding: 6px 12px;
}

.dataTables_wrapper .dataTables_paginate .paginate_button.current {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    border-color: #667eea !important;
    color: white !important;
    border-radius: 8px;
}

.dataTables_wrapper .dataTables_paginate .paginate_button:hover {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    border-color: #667eea !important;
    color: white !important;
}

/* ===== Responsive ===== */
@media (max-width: 768px) {
    .header .title {
        font-size: 18px;
        margin-left: 20px;
    }
    
    .hamburger-btn.shifted {
        left: 295px;
    }
    
    .sidebar {
        width: 280px;
        left: -280px;
    }
    
    .table-responsive {
        font-size: 0.75rem;
    }
}
</style>
</head>
<body>

<!-- Hamburger Button -->
<button class="hamburger-btn" id="hamburgerBtn">
    <i class="fas fa-bars"></i>
</button>

<!-- Sidebar -->
<div id="sidebar" class="sidebar">
    <div class="sidebar-header">
        <h3><i class="fas fa-chart-line"></i> Dashboard Utama</h3>
    </div>
    <br>
    <ul class="sidebar-menu">
        <li><a href="../index.php"><i class="fas fa-home"></i> Dashboard</a></li>

        <li class="dropdown">
            <a href="#" class="dropdown-toggle"><i class="fas fa-database"></i> Master Data <span class="arrow"></span></a>
            <ul class="submenu">
                <li><a href="../master/partner.php"><i class="fas fa-handshake"></i> Partner</a></li>
                <li><a href="../master/ttd.php"><i class="fas fa-signature"></i> Tanda Tangan</a></li>
                <li><a href="../master/kendaraan.php"><i class="fas fa-truck"></i> Kendaraan</a></li>
                <li><a href="../master/barang.php"><i class="fas fa-box"></i> Barang</a></li>
                <li><a href="../master/dermaga.php"><i class="fas fa-anchor"></i> Dermaga</a></li>
                <li><a href="../master/harga.php"><i class="fas fa-dollar-sign"></i> Harga</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" class="dropdown-toggle"><i class="fas fa-exchange-alt"></i> Transaksi <span class="arrow"></span></a>
            <ul class="submenu">
                <li><a href="../transaksi/sales_order.php"><i class="fas fa-shopping-cart"></i> Sales Order</a></li>
                <li><a href="../transaksi/purchase_order.php"><i class="fas fa-shopping-bag"></i> Purchase Order</a></li>
                <li><a href="../transaksi/surat_jalan.php"><i class="fas fa-file-alt"></i> Surat Jalan</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" class="dropdown-toggle"><i class="fas fa-file-invoice"></i> Laporan <span class="arrow"></span></a>
            <ul class="submenu">
                <li><a href="../laporan/order_kerja.php"><i class="fas fa-clipboard-list"></i> Order Kerja</a></li>
                <li><a href="../laporan/invoice.php"><i class="fas fa-file-invoice-dollar"></i> Invoice</a></li>
                <li><a href="../laporan/kwitansi.php"><i class="fas fa-receipt"></i> Kwitansi</a></li>
                <li><a href="../laporan/laporan_realisasi.php"><i class="fas fa-chart-bar"></i> Realisasi</a></li>
            </ul>
        </li>

        <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</div>

<!-- Overlay -->
<div id="overlay"></div>

<!-- Header -->
<div class="header">
    <div class="title">Purchase Order</div>
    <div class="user-info">
        <span class="username"><i class="fas fa-user-circle"></i> <?= htmlspecialchars($username) ?></span>
        <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</div>

<!-- Main Content -->
<div class="container-fluid mt-4 main-content">
    <?php if(isset($success)): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $success ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if(isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card">
<div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
    <h5><i class="fas fa-shopping-bag"></i> Purchase Order</a></li></h5>
    <div>
        <button onclick="exportToExcel()" class="btn btn-success btn-sm me-2">
            <i class="bi bi-file-earmark-excel"></i> Export ke Excel
        </button>
        <button class="btn btn-light btn-sm" data-bs-toggle="modal" data-bs-target="#modalTambah">
            <i class="bi bi-plus-circle"></i> Tambah Purchase Order
        </button>
    </div>
</div>
        <div class="card-body">
            <div class="table-responsive">
                <table id="tablePO" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Sales Order</th>
                            <th>Uraian Pekerjaan</th>
                            <th>Periode</th>
                            <th>Purchase Order</th>
                            <th>Tanggal PO</th>
                            <th>Terima PO</th>
                            <th>Nomor BA</th>
                            <th>Tanggal BA</th>
                            <th>Terima BA</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1;
                        while($row = $result->fetch_assoc()): 
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= htmlspecialchars($row['nomor_so'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($row['uraian_pekerjaan']) ?></td>
                            <td><?= htmlspecialchars($row['periode']) ?></td>
                            <td><?= htmlspecialchars($row['nomor_po']) ?></td>
                            <td><?= $row['tanggal_po'] ? date('d/m/Y', strtotime($row['tanggal_po'])) : '-' ?></td>
                            <td><?= $row['terima_po'] ? date('d/m/Y', strtotime($row['terima_po'])) : '-' ?></td>
                            <td><?= htmlspecialchars($row['nomor_berita_acara'] ?? '-') ?></td>
                            <td><?= $row['tanggal_ba'] ? date('d/m/Y', strtotime($row['tanggal_ba'])) : '-' ?></td>
                            <td><?= $row['terima_ba'] ? date('d/m/Y', strtotime($row['terima_ba'])) : '-' ?></td>
                            <td>
                                <button class="btn btn-warning btn-sm btn-action" 
                                        onclick="editPO(<?= htmlspecialchars(json_encode($row)) ?>)"> <i class="fas fa-edit"></i>
                                </button>
                                <a href="?hapus=<?= $row['po_id'] ?>" 
                                   class="btn btn-danger btn-sm btn-action"
                                   onclick="return confirm('Yakin ingin menghapus data ini?')"><i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah -->
<div class="modal fade" id="modalTambah" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Tambah Purchase Order</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Sales Order</label>
                            <select class="form-select" name="so_id" required>
                                <option value="">Pilih Sales Order</option>
                                <?php 
                                $result_so->data_seek(0);
                                while($so = $result_so->fetch_assoc()): 
                                ?>
                                <option value="<?= $so['so_id'] ?>"><?= htmlspecialchars($so['nomor_so']) ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Uraian Pekerjaan <span class="text-danger">*</span></label>
                            <select class="form-select" name="uraian_pekerjaan" required>
                                <option value="">Pilih Kapal (Uraian Pekerjaan)</option>
                                <?php 
                                $result_kapal->data_seek(0);
                                while($kapal = $result_kapal->fetch_assoc()): 
                                ?>
                                <option value="<?= htmlspecialchars($kapal['nama_kapal']) ?>"><?= htmlspecialchars($kapal['nama_kapal']) ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Periode <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="periode" placeholder="contoh: 01 - 05 DESEMBER 2021" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nomor PO <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="nomor_po" placeholder="contoh: 5120249596" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal PO</label>
                            <input type="date" class="form-control" name="tanggal_po">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Terima PO</label>
                            <input type="date" class="form-control" name="terima_po">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nomor Berita Acara</label>
                            <input type="text" class="form-control" name="nomor_berita_acara">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal BA</label>
                            <input type="date" class="form-control" name="tanggal_ba">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Terima BA</label>
                        <input type="date" class="form-control" name="terima_ba">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="tambah" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Edit -->
<div class="modal fade" id="modalEdit" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title">Edit Purchase Order</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="po_id" id="edit_po_id">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Sales Order</label>
                            <select class="form-select" name="so_id" id="edit_so_id">
                                <option value="">Pilih Sales Order</option>
                                <?php 
                                $result_so->data_seek(0);
                                while($so = $result_so->fetch_assoc()): 
                                ?>
                                <option value="<?= $so['so_id'] ?>"><?= htmlspecialchars($so['nomor_so']) ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Uraian Pekerjaan <span class="text-danger">*</span></label>
                            <select class="form-select" name="uraian_pekerjaan" id="edit_uraian_pekerjaan" required>
                                <option value="">Pilih Kapal (Uraian Pekerjaan)</option>
                                <?php 
                                $result_kapal->data_seek(0);
                                while($kapal = $result_kapal->fetch_assoc()): 
                                ?>
                                <option value="<?= htmlspecialchars($kapal['nama_kapal']) ?>"><?= htmlspecialchars($kapal['nama_kapal']) ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Periode <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="periode" id="edit_periode" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nomor PO <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="nomor_po" id="edit_nomor_po" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal PO</label>
                            <input type="date" class="form-control" name="tanggal_po" id="edit_tanggal_po">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Terima PO</label>
                            <input type="date" class="form-control" name="terima_po" id="edit_terima_po">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nomor Berita Acara</label>
                            <input type="text" class="form-control" name="nomor_berita_acara" id="edit_nomor_berita_acara">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal BA</label>
                            <input type="date" class="form-control" name="tanggal_ba" id="edit_tanggal_ba">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Terima BA</label>
                        <input type="date" class="form-control" name="terima_ba" id="edit_terima_ba">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="edit" class="btn btn-warning">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

<script>
// DataTable
$(document).ready(function() {
    $('#tablePO').DataTable({
        language: {
            url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/id.json'
        }
    });
});

// Hamburger toggle
const hamburger = document.getElementById('hamburgerBtn');
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');

function openSidebar(){
    sidebar.classList.add('active');
    overlay.classList.add('active');
    hamburger.classList.add('shifted');
}
function closeSidebar(){
    sidebar.classList.remove('active');
    overlay.classList.remove('active');
    hamburger.classList.remove('shifted');
}
hamburger.addEventListener('click', () => {
    if(sidebar.classList.contains('active')){
        closeSidebar();
    } else {
        openSidebar();
    }
});
overlay.addEventListener('click', closeSidebar);

// Dropdown toggle
document.querySelectorAll('.dropdown-toggle').forEach(toggle => {
    toggle.addEventListener('click', function(e){
        e.preventDefault();
        this.classList.toggle('active');
        const submenu = this.nextElementSibling;
        if(submenu){
            submenu.classList.toggle('active');
        }
    });
});

// Edit PO
function editPO(data) {
    document.getElementById('edit_po_id').value = data.po_id;
    document.getElementById('edit_so_id').value = data.so_id || '';
    document.getElementById('edit_uraian_pekerjaan').value = data.uraian_pekerjaan;
    document.getElementById('edit_periode').value = data.periode;
    document.getElementById('edit_nomor_po').value = data.nomor_po;
    document.getElementById('edit_tanggal_po').value = data.tanggal_po || '';
    document.getElementById('edit_terima_po').value = data.terima_po || '';
    document.getElementById('edit_nomor_berita_acara').value = data.nomor_berita_acara || '';
    document.getElementById('edit_tanggal_ba').value = data.tanggal_ba || '';
    document.getElementById('edit_terima_ba').value = data.terima_ba || '';
    
    var modalEdit = new bootstrap.Modal(document.getElementById('modalEdit'));
    modalEdit.show();
}

function exportToExcel() {
    // Ambil data dari DataTable
    const table = $('#tablePO').DataTable();
    const data = [];

    // Header
    const headers = [
        'No', 'Sales Order', 'Uraian Pekerjaan', 'Periode',
        'Purchase Order', 'Tanggal PO', 'Terima PO',
        'Nomor BA', 'Tanggal BA', 'Terima BA'
    ];
    data.push(headers);

    // Ambil semua data (termasuk yang difilter)
    table.rows({ search: 'applied' }).every(function() {
        const rowNode = this.node();

        // Extract text content dari setiap cell
        const row = [
            $(rowNode).find('td').eq(0).text().trim(), // No
            $(rowNode).find('td').eq(1).text().trim(), // Sales Order
            $(rowNode).find('td').eq(2).text().trim(), // Uraian Pekerjaan
            $(rowNode).find('td').eq(3).text().trim(), // Periode
            $(rowNode).find('td').eq(4).text().trim(), // Purchase Order
            $(rowNode).find('td').eq(5).text().trim(), // Tanggal PO
            $(rowNode).find('td').eq(6).text().trim(), // Terima PO
            $(rowNode).find('td').eq(7).text().trim(), // Nomor BA
            $(rowNode).find('td').eq(8).text().trim(), // Tanggal BA
            $(rowNode).find('td').eq(9).text().trim(), // Terima BA
        ];
        data.push(row);
    });

    // Buat workbook dan worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(data);

    // Set column widths
    ws['!cols'] = [
        { wch: 5 },  // No
        { wch: 20 }, // Sales Order
        { wch: 30 }, // Uraian Pekerjaan
        { wch: 30 }, // Periode
        { wch: 20 }, // Purchase Order
        { wch: 12 }, // Tanggal PO
        { wch: 12 }, // Terima PO
        { wch: 25 }, // Nomor BA
        { wch: 12 }, // Tanggal BA
        { wch: 12 }  // Terima BA
    ];

    // Add worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Purchase Order');

    // Generate filename dengan tanggal
    const today = new Date();
    const filename = `Purchase_Order_${today.getFullYear()}${(today.getMonth()+1).toString().padStart(2,'0')}${today.getDate().toString().padStart(2,'0')}.xlsx`;

    // Download file
    XLSX.writeFile(wb, filename);
}
</script>

</body>
</html>