  </div> <!-- end col-md-10 -->
</div> <!-- end row -->
</div> <!-- end container-fluid -->
<footer class="bg-dark text-white text-center py-3 mt-4">
    &copy; <?= date('Y') ?> Admin Dashboard
</footer>
</body>
</html>
