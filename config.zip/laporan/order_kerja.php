<?php
session_start();
if(!isset($_SESSION['admin'])){
    header("Location: ../login.php");
    exit;
}

include "../config/database.php";

// Ambil username admin
$admin_id = $_SESSION['admin'];
$stmt = $conn->prepare("SELECT username FROM user_admin WHERE id=?");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();
$username = $admin['username'];

// ===== HAPUS =====
if(isset($_POST['delete'])){
    $ok_id = intval($_POST['delete']);
    $stmt = $conn->prepare("DELETE FROM order_kerja WHERE ok_id=?");
    $stmt->bind_param("i", $ok_id);
    if($stmt->execute()){
        echo "<script>alert('Order Kerja berhasil dihapus!'); window.location.href='order_kerja.php';</script>";
    } else {
        echo "<script>alert('Gagal hapus: ".$stmt->error."'); window.location.href='order_kerja.php';</script>";
    }
    exit;
}

// ===== EDIT/UPDATE =====
if(isset($_POST['update'])){
    $ok_id = intval($_POST['ok_id']);
    $nomor_ok = trim($_POST['nomor_ok']);
    $tanggal_ok = $_POST['tanggal_ok'];
    $partner_id = intval($_POST['partner_id']);
    $kapal_id = intval($_POST['kapal_id']);
    $potongan_persentase = floatval($_POST['potongan_persentase']);
    $denda = floatval($_POST['denda']);
    $ttd_id = !empty($_POST['ttd_id']) ? intval($_POST['ttd_id']) : null;

    // Hitung total tonase dari SO untuk kapal ini
    $stmt = $conn->prepare("SELECT SUM(qty) as total_qty FROM sales_order WHERE kapal_id = ?");
    $stmt->bind_param("i", $kapal_id);
    $stmt->execute();
    $so_data = $stmt->get_result()->fetch_assoc();
    $total_tonase = floatval($so_data['total_qty'] ?? 0);

    // Update order kerja
    $stmt = $conn->prepare("UPDATE order_kerja SET 
        nomor_ok=?, tanggal_ok=?, partner_id=?, kapal_id=?, 
        total_tonase=?, potongan_persentase=?, denda=?, ttd_id=?
        WHERE ok_id=?");
    
    $stmt->bind_param(
        "ssiidddii",
        $nomor_ok,
        $tanggal_ok,
        $partner_id,
        $kapal_id,
        $total_tonase,
        $potongan_persentase,
        $denda,
        $ttd_id,
        $ok_id
    );
    
    if($stmt->execute()){
        echo "<script>alert('Order Kerja berhasil diupdate!'); window.location.href='order_kerja.php';</script>";
    } else {
        echo "<script>alert('Gagal update: ".$stmt->error."'); window.history.back();</script>";
    }
    exit;
}

// ===== TAMBAH =====
if(isset($_POST['submit'])){
    $nomor_ok = trim($_POST['nomor_ok']);
    $tanggal_ok = $_POST['tanggal_ok'];
    $partner_id = intval($_POST['partner_id']);
    $kapal_id = intval($_POST['kapal_id']);
    $potongan_persentase = floatval($_POST['potongan_persentase']);
    $denda = floatval($_POST['denda']);
    $ttd_id = !empty($_POST['ttd_id']) ? intval($_POST['ttd_id']) : null;

    // Hitung total tonase dari SO untuk kapal ini
    $stmt = $conn->prepare("SELECT SUM(qty) as total_qty FROM sales_order WHERE kapal_id = ?");
    $stmt->bind_param("i", $kapal_id);
    $stmt->execute();
    $so_data = $stmt->get_result()->fetch_assoc();
    $total_tonase = floatval($so_data['total_qty'] ?? 0);

    // Insert order kerja
    $harga_id = null;
    $stmt = $conn->prepare("INSERT INTO order_kerja 
    (nomor_ok, tanggal_ok, partner_id, kapal_id, total_tonase, potongan_persentase, denda, ttd_id, harga_id)
    VALUES (?,?,?,?,?,?,?,?,?)");
    
    if(!$stmt){
        echo "<script>alert('Error: ".$conn->error."'); window.history.back();</script>";
        exit;
    }

    $stmt->bind_param(
        "ssiidddii",
        $nomor_ok,
        $tanggal_ok,
        $partner_id,
        $kapal_id,
        $total_tonase,
        $potongan_persentase,
        $denda,
        $ttd_id,
        $harga_id
    );
    
    if($stmt->execute()){
        echo "<script>alert('Order Kerja berhasil ditambahkan!'); window.location.href='order_kerja.php';</script>";
    } else {
        echo "<script>alert('Gagal tambah: ".$stmt->error."'); window.history.back();</script>";
    }
    exit;
}

// Ambil data Order Kerja
$result = $conn->query("
    SELECT ok.*, k.nama_kapal, p.partner as singkatan_partner, p.nama_partner
    FROM order_kerja ok
    LEFT JOIN kapal k ON ok.kapal_id = k.kapal_id
    LEFT JOIN partner p ON ok.partner_id = p.partner_id
    ORDER BY ok.tanggal_ok DESC
");

// Mode edit
$editRow = null;
if(isset($_GET['edit'])){
    $editId = intval($_GET['edit']);
    $stmt = $conn->prepare("
        SELECT ok.*
        FROM order_kerja ok
        WHERE ok.ok_id=?
    ");
    $stmt->bind_param("i", $editId);
    $stmt->execute();
    $res = $stmt->get_result();
    $editRow = $res->fetch_assoc();
}

// Ambil data untuk dropdown
$partner_list = $conn->query("SELECT partner_id, partner, nama_partner, kategori FROM partner ORDER BY kategori, nama_partner");

// Hanya kapal aktif
$kapal_list = $conn->query("
    SELECT k.kapal_id, k.nama_kapal 
    FROM kapal k
    LEFT JOIN order_kerja ok ON k.kapal_id = ok.kapal_id
    WHERE k.status='aktif' AND ok.ok_id IS NULL
    ORDER BY k.nama_kapal
");

// TTD
$ttd_list = $conn->query("SELECT ttd_id, nama, jabatan FROM ttd ORDER BY nama");

?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Order Kerja Management</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    background: linear-gradient(135deg, #3e4e92ff 0%, #764ba2 100%);
    min-height: 100vh;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* ===== Sidebar ===== */
.main-content {
    margin-left: 0px;
    transition: all 0.3s ease;
}

.sidebar {
    position: fixed;
    top: 0;
    left: -320px;
    width: 320px;
    height: 100%;
    background: linear-gradient(180deg, #1e3c72 0%, #2a5298 100%);
    color: #fff;
    overflow-y: auto;
    transition: all 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    z-index: 1050;
    box-shadow: 4px 0 20px rgba(0, 0, 0, 0.3);
}

.sidebar::-webkit-scrollbar {
    width: 8px;
}

.sidebar::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.1);
}

.sidebar::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.3);
    border-radius: 10px;
}

.sidebar.active { 
    left: 0;
    box-shadow: 4px 0 30px rgba(0, 0, 0, 0.5);
}

.sidebar-header { 
    padding: 25px 20px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-bottom: 2px solid rgba(255, 255, 255, 0.1);
}

.sidebar-header h3 {
    font-size: 22px;
    font-weight: 700;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    letter-spacing: 0.5px;
}

.sidebar-menu { 
    list-style: none;
    padding: 15px 0;
    margin: 0;
}

.sidebar-menu li { 
    list-style: none;
    padding: 5px 15px;
    margin: 3px 0;
}

.sidebar-menu li a {
    color: #fff;
    text-decoration: none;
    display: flex;
    align-items: center;
    padding: 14px 18px;
    border-radius: 12px;
    transition: all 0.3s ease;
    font-size: 15px;
    font-weight: 500;
    position: relative;
    overflow: hidden;
}

.sidebar-menu li a::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 4px;
    background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
    transform: scaleY(0);
    transition: transform 0.3s ease;
}

.sidebar-menu li a:hover {
    background: rgba(255, 255, 255, 0.15);
    padding-left: 28px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}

.sidebar-menu li a:hover::before {
    transform: scaleY(1);
}

.sidebar-menu li a i {
    margin-right: 12px;
    font-size: 18px;
    width: 25px;
    text-align: center;
}

/* ===== Hamburger ===== */
.hamburger-btn {
    position: fixed;
    top: 10px;
    left: 18px;
    z-index: 1100;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border: none;
    color: #fff;
    padding: 12px 16px;
    font-size: 22px;
    cursor: pointer;
    border-radius: 12px;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
}

.hamburger-btn:hover {
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.4);
}

.hamburger-btn.shifted { 
    left: 335px;
}

/* ===== Overlay ===== */
#overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(3px);
    display: none;
    z-index: 1040;
    transition: all 0.3s ease;
}

#overlay.active { display: block; }

/* ===== Dropdown custom ===== */
.submenu { 
    display: none;
    padding-left: 20px;
    list-style: none;
    margin-top: 5px;
}

.submenu.active { 
    display: block !important;
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.submenu li a {
    padding: 10px 18px;
    font-size: 14px;
    background: rgba(255, 255, 255, 0.05);
    margin: 3px 0;
}

.arrow { 
    float: right;
    transition: transform 0.3s ease;
    font-size: 12px;
}

.arrow::before { 
    font-size: 11px;
}

.dropdown-toggle.active .arrow {
    transform: rotate(180deg);
}

.dropdown-toggle::after {
    display: none;
}

/* ===== Header ===== */
.header {
    position: sticky;
    top: 0;
    left: 0;
    right: 0;
    height: 80px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 30px;
    z-index: 1030;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
    backdrop-filter: blur(10px);
}

.header .title { 
    margin-left: 50px;
    font-size: 24px;
    font-weight: 700;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    letter-spacing: 0.5px;
}

.header .user-info { 
    font-size: 15px;
    display: flex;
    align-items: center;
    gap: 15px;
    font-weight: 500;
}

.header .user-info .username {
    padding: 8px 18px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 20px;
    backdrop-filter: blur(10px);
}

.header .user-info a.logout-btn {
    background: linear-gradient(135deg, #ff416c, #ff4b2b);
    color: #fff;
    padding: 10px 24px;
    border-radius: 25px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(52, 11, 21, 0.4);
    display: inline-block;
}

.header .user-info a.logout-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(255, 65, 108, 0.5);
    filter: brightness(1.1);
}

/* ===== Main Content ===== */
.container-fluid {
    padding: 30px;
}

/* ===== Card Styles ===== */
.card {
    border: none;
    border-radius: 18px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    background: rgba(255, 255, 255, 0.98);
    backdrop-filter: blur(10px);
    animation: fadeInUp 0.5s ease;
    margin-bottom: 30px;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.card-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    border: none;
    border-radius: 18px 18px 0 0 !important;
    padding: 20px 25px;
    color: white;
}

.card-header h5 {
    margin: 0;
    font-weight: 700;
    font-size: 20px;
    text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2);
}

.card-body {
    padding: 25px;
}

/* ===== Button Styles ===== */
.btn {
    border-radius: 10px;
    padding: 8px 20px;
    font-weight: 600;
    transition: all 0.3s ease;
    border: none;
}

.btn-success {
    background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
    color: #fff;
}

.btn-success:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(17, 153, 142, 0.4);
    filter: brightness(1.1);
}

.btn-danger {
    background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%);
    color: #fff;
}

.btn-danger:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(255, 65, 108, 0.4);
    filter: brightness(1.1);
}

.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
    filter: brightness(1.1);
}

.btn-secondary {
    background: linear-gradient(135deg, #868f96 0%, #596164 100%);
}

.btn-secondary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(134, 143, 150, 0.4);
    filter: brightness(1.1);
}

.btn-action {
    margin: 0 3px;
    font-size: 12px;
    padding: 4px 8px;
}

/* ===== Table Styles ===== */
.table-responsive {
    border-radius: 12px;
    overflow-x: auto;
    overflow-y: visible;
    -webkit-overflow-scrolling: touch;
}

.table {
    margin: 0;
    background: white;
}

.table thead th {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    font-weight: 600;
    border: none;
    padding: 12px 8px;
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.5px;
}

.table tbody tr {
    transition: all 0.3s ease;
}

.table tbody tr:hover {
    background: rgba(102, 126, 234, 0.1);
    transform: scale(1.002);
}

.table tbody td {
    padding: 12px 8px;
    vertical-align: middle;
}

.form-label {
    font-weight: 600;
    color: #2a5298;
    margin-bottom: 8px;
    font-size: 0.9rem;
}

.form-control, .form-select {
    border: 2px solid #e0e6ed;
    border-radius: 10px;
    padding: 10px 15px;
    transition: all 0.3s ease;
}

.form-control:focus, .form-select:focus {
    border-color: #667eea;
    box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
}

.detail-table {
    font-size: 13px;
}

.detail-table th {
    background: #f1f3f5;
    font-weight: 600;
}

.badge-area {
    background: #e7f3ff;
    color: #0066cc;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 11px;
}

/* ===== Responsive ===== */
@media (max-width: 768px) {
    .header .title {
        font-size: 18px;
        margin-left: 20px;
    }
    
    .hamburger-btn.shifted {
        left: 295px;
    }
    
    .sidebar {
        width: 280px;
        left: -280px;
    }
}
</style>
</head>
<body>

<!-- Hamburger Button -->
<button class="hamburger-btn" id="hamburgerBtn">
    <i class="fas fa-bars"></i>
</button>

<!-- Sidebar -->
<div id="sidebar" class="sidebar">
    <div class="sidebar-header">
        <h3><i class="fas fa-chart-line"></i> Dashboard Utama</h3>
    </div>
    <br>
    <ul class="sidebar-menu">
        <li><a href="../index.php"><i class="fas fa-home"></i> Dashboard</a></li>

        <li class="dropdown">
            <a href="#" class="dropdown-toggle"><i class="fas fa-database"></i> Master Data <span class="arrow"></span></a>
            <ul class="submenu">
                <li><a href="../master/partner.php"><i class="fas fa-handshake"></i> Partner</a></li>
                <li><a href="../master/ttd.php"><i class="fas fa-signature"></i> Tanda Tangan</a></li>
                <li><a href="../master/kendaraan.php"><i class="fas fa-truck"></i> Kendaraan</a></li>
                <li><a href="../master/barang.php"><i class="fas fa-box"></i> Barang</a></li>
                <li><a href="../master/dermaga.php"><i class="fas fa-anchor"></i> Dermaga</a></li>
                <li><a href="../master/harga.php"><i class="fas fa-dollar-sign"></i> Harga</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" class="dropdown-toggle"><i class="fas fa-exchange-alt"></i> Transaksi <span class="arrow"></span></a>
            <ul class="submenu">
                <li><a href="../transaksi/sales_order.php"><i class="fas fa-shopping-cart"></i> Sales Order</a></li>
                <li><a href="../transaksi/purchase_order.php"><i class="fas fa-shopping-bag"></i> Purchase Order</a></li>
                <li><a href="../transaksi/surat_jalan.php"><i class="fas fa-file-alt"></i> Surat Jalan</a></li>
            </ul>
        </li>
        
        <li class="dropdown">
            <a href="#" class="dropdown-toggle"><i class="fas fa-file-invoice"></i> Laporan <span class="arrow"></span></a>
            <ul class="submenu">
                <li><a href="../laporan/order_kerja.php"><i class="fas fa-clipboard-list"></i> Order Kerja</a></li>
                <li><a href="../laporan/invoice.php"><i class="fas fa-file-invoice-dollar"></i> Invoice</a></li>
                <li><a href="../laporan/kwitansi.php"><i class="fas fa-receipt"></i> Kwitansi</a></li>
                <li><a href="../laporan/laporan_realisasi.php"><i class="fas fa-chart-bar"></i> Realisasi</a></li>
            </ul>
        </li>

        <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</div>

<!-- Overlay -->
<div id="overlay"></div>

<!-- Header -->
<div class="header">
    <div class="title">Order Kerja Management</div>
    <div class="user-info">
        <span class="username"><i class="fas fa-user-circle"></i> <?= htmlspecialchars($username) ?></span>
        <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</div>

<div class="container-fluid main-content">
    <!-- Form Tambah/Edit Order Kerja -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">
                <i class="fas fa-file-<?= $editRow ? 'pen' : 'plus' ?>"></i> 
                <?= $editRow ? 'Edit Order Kerja' : 'Form Order Kerja Baru' ?>
            </h5>
        </div>
        <div class="card-body">
            <form method="POST" id="formOrderKerja">
                <?php if($editRow): ?>
                <input type="hidden" name="ok_id" value="<?= $editRow['ok_id'] ?>">
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Nomor OK <span class="text-danger">*</span></label>
                        <input type="text" name="nomor_ok" class="form-control" 
                            value="<?= $editRow ? htmlspecialchars($editRow['nomor_ok']) : '' ?>"
                            placeholder="OK/2025/001" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Tanggal OK <span class="text-danger">*</span></label>
                        <input type="date" name="tanggal_ok" class="form-control" 
                            value="<?= $editRow ? $editRow['tanggal_ok'] : date('Y-m-d') ?>" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Partner <span class="text-danger">*</span></label>
                        <select name="partner_id" id="partner_id" class="form-select" required>
                            <option value="">-- Pilih Partner --</option>
                            <?php 
                            while($row = $partner_list->fetch_assoc()): 
                            ?>
                                <option value="<?= $row['partner_id'] ?>" 
                                    <?= ($editRow && $editRow['partner_id'] == $row['partner_id']) ? 'selected' : '' ?>
                                    data-singkatan="<?= $row['partner'] ?>">
                                    <?= htmlspecialchars($row['partner']) ?> - <?= htmlspecialchars($row['nama_partner']) ?> (<?= $row['kategori'] ?>)
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Kapal <span class="text-danger">*</span></label>
                        <select name="kapal_id" id="kapal_id" class="form-select" required>
                            <option value="">-- Pilih Kapal --</option>
                            <?php 
                            while($row = $kapal_list->fetch_assoc()): 
                            ?>
                                <option value="<?= $row['kapal_id'] ?>" 
                                    <?= ($editRow && $editRow['kapal_id'] == $row['kapal_id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($row['nama_kapal']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                        <small class="text-muted">Sistem akan otomatis menampilkan semua area dari kapal yang dipilih</small>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label" >Potongan (%)</label>
                        <input type="number" name="potongan_persentase" id="potongan_persentase" class="form-control" step="0.01" 
                            value="<?= $editRow ? $editRow['potongan_persentase'] : '0' ?>" placeholder="Masukkan persentase potongan">
                        <small class="text-muted">Contoh: 5 untuk potongan 5%</small>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Denda (Rp)</label>
                        <input type="number" name="denda" id="denda" class="form-control" step="0.01" 
                            value="<?= $editRow ? $editRow['denda'] : '0' ?>" placeholder="Masukkan nominal denda">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Tanda Tangan</label>
                        <select name="ttd_id" class="form-select">
                            <option value="">-- Pilih Tanda Tangan Penerima --</option>
                            <?php 
                            $ttd_list->data_seek(0); 
                            while($row = $ttd_list->fetch_assoc()): 
                            ?>
                                <option value="<?= $row['ttd_id'] ?>"
                                    <?= ($editRow && $editRow['ttd_id'] == $row['ttd_id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($row['nama']) ?> - <?= htmlspecialchars($row['jabatan']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Preview Detail per Area</label>
                    <div id="previewDetail" class="border rounded p-3 bg-light">
                        <p class="text-muted text-center">Pilih Kapal untuk melihat detail per area</p>
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <?php if($editRow): ?>
                    <button type="submit" name="update" class="btn btn-success">
                        <i class="fas fa-save"></i> Update Order Kerja
                    </button>
                    <a href="order_kerja.php" class="btn btn-secondary">
                        <i class="fas fa-times-circle"></i> Batal
                    </a>
                    <?php else: ?>
                    <button type="submit" name="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Simpan Order Kerja
                    </button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <!-- Daftar Order Kerja -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-list"></i> Daftar Order Kerja</h5>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-8">
                    <input type="text" id="searchOK" class="form-control" placeholder="🔍 Cari nomor OK, partner, kapal...">
                </div>
                <div class="col-md-4 text-end">
                    <button onclick="exportToExcel()" class="btn btn-success">
                        <i class="fas fa-file-excel"></i> Export ke Excel
                    </button>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th width="20">No</th>
                            <th>No. OK</th>
                            <th>Tanggal</th>
                            <th>Partner</th>
                            <th>Kapal</th>
                            <th>Total Tonase</th>
                            <th>Potongan %</th>
                            <th>Denda</th>
                            <th width="100">Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="okTable">
                        <?php if($result && $result->num_rows > 0): 
                            $no = 1;
                            while($row = $result->fetch_assoc()): 
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><strong class="text-primary"><?= htmlspecialchars($row['nomor_ok']) ?></strong></td>
                            <td><?= date('d/m/Y', strtotime($row['tanggal_ok'])) ?></td>
                            <td><?= htmlspecialchars($row['singkatan_partner']) ?></td>
                            <td><?= htmlspecialchars($row['nama_kapal']) ?></td>
                            <td><?= number_format($row['total_tonase'], 3, ',', '.') ?> Ton</td>
                            <td><?= number_format($row['potongan_persentase'], 2, ',', '.') ?>%</td>
                            <td>Rp <?= number_format($row['denda'], 0, ',', '.') ?></td>
                            <td>
                                <a href="cetak_order_kerja.php?ok_id=<?= $row['ok_id'] ?>" target="_blank" class="btn btn-sm btn-success btn-action">
                                    <i class="fas fa-print"></i>
                                </a>
                                <form method="POST" style="display:inline;" onsubmit="return confirm('Yakin hapus order kerja ini?')">
                                    <input type="hidden" name="delete" value="<?= $row['ok_id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-danger btn-action">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; else: ?>
                        <tr>
                            <td colspan="9" class="text-center text-muted">Tidak ada data order kerja</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

<script>
// Sidebar Toggle
const hamburger = document.getElementById('hamburgerBtn');
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');

function openSidebar(){
    sidebar.classList.add('active');
    overlay.classList.add('active');
    hamburger.classList.add('shifted');
}

function closeSidebar(){
    sidebar.classList.remove('active');
    overlay.classList.remove('active');
    hamburger.classList.remove('shifted');
}

hamburger.addEventListener('click', () => {
    if(sidebar.classList.contains('active')){
        closeSidebar();
    } else {
        openSidebar();
    }
});

overlay.addEventListener('click', closeSidebar);

// Dropdown submenu
document.querySelectorAll('.dropdown-toggle').forEach(toggle=>{
    toggle.addEventListener('click', function(e){
        e.preventDefault();
        this.classList.toggle('active');
        const submenu = this.nextElementSibling;
        if(submenu){ submenu.classList.toggle('active'); }
    });
});

// Preview Detail - Load on page load if editing
<?php if($editRow): ?>
window.addEventListener('DOMContentLoaded', function() {
    loadPreview(<?= $editRow['kapal_id'] ?>);
});
<?php endif; ?>

// Preview Detail
document.getElementById('kapal_id').addEventListener('change', function() {
    loadPreview(this.value);
});

async function loadPreview(kapalId) {
    const preview = document.getElementById('previewDetail');
    
    if(!kapalId) {
        preview.innerHTML = '<p class="text-muted text-center">Pilih Kapal untuk melihat detail per area</p>';
        return;
    }
    
    preview.innerHTML = '<p class="text-center"><i class="fas fa-hourglass-split"></i> Memuat data...</p>';
    
    try {
        const response = await fetch('get_ok_detail.php?kapal_id=' + kapalId);
        const data = await response.json();
        
        if(data.success && data.areas.length > 0) {
            let html = '<div class="table-responsive"><table class="table table-sm detail-table mb-0">';
            html += '<thead><tr><th>No</th><th>Area</th><th>QTY (Ton)</th><th>Harga</th><th>Subtotal</th></tr></thead><tbody>';
            
            let no = 1;
            data.areas.forEach(area => {
                html += `<tr>
                    <td>${no++}</td>
                    <td>${area.area}</td>
                    <td class="text-justify">${area.qty}</td>
                    <td class="text-justify">Rp ${area.harga}</td>
                    <td class="text-justify fw-bold">Rp ${area.subtotal}</td>
                </tr>`;
            });
            
            html += `</tbody><tfoot>
                <tr class="table-info">
                    <th colspan="2">TOTAL</th>
                    <th class="text-justify">${data.total_qty} Ton</th>
                    <th></th>
                    <th class="text-justify">Rp ${data.total_biaya}</th>
                </tr>
            </tfoot></table></div>`;
            
            preview.innerHTML = html;
        } else {
            preview.innerHTML = '<p class="text-danger">Tidak ada data Sales Order untuk kapal ini</p>';
        }
    } catch(e) {
        preview.innerHTML = '<p class="text-danger">Error: ' + e.message + '</p>';
    }
}

// Search Order Kerja
document.getElementById('searchOK').addEventListener('keyup', function() {
    const filter = this.value.toLowerCase();
    const rows = document.querySelectorAll('#okTable tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(filter) ? '' : 'none';
    });
});

function exportToExcel() {
    // Ambil data dari tabel
    const table = document.querySelector('#okTable').closest('table');
    const rows = [];
    
    // Header
    const headers = ['No', 'No. OK', 'Tanggal', 'Partner', 'Kapal', 'Total Tonase', 'Potongan %', 'Denda'];
    rows.push(headers);
    
    // Data rows (hanya yang visible)
    const tableRows = document.querySelectorAll('#okTable tr');
    tableRows.forEach((row, index) => {
        if (row.style.display !== 'none' && row.cells.length > 1) {
            const rowData = [
                row.cells[0].textContent.trim(),
                row.cells[1].textContent.trim(),
                row.cells[2].textContent.trim(),
                row.cells[3].textContent.trim(),
                row.cells[4].textContent.trim(),
                row.cells[5].textContent.trim(),
                row.cells[6].textContent.trim(),
                row.cells[7].textContent.replace('Rp ', '').trim()
            ];
            rows.push(rowData);
        }
    });
    
    // Buat workbook dan worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(rows);
    
    // Set column widths
    ws['!cols'] = [
        { wch: 5 },  // No
        { wch: 20 }, // No. OK
        { wch: 12 }, // Tanggal
        { wch: 15 }, // Partner
        { wch: 25 }, // Kapal
        { wch: 15 }, // Total Tonase
        { wch: 12 }, // Potongan %
        { wch: 15 }  // Denda
    ];
    
    // Add worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Order Kerja');
    
    // Generate filename dengan tanggal
    const today = new Date();
    const filename = `Order_Kerja_${today.getFullYear()}${(today.getMonth()+1).toString().padStart(2,'0')}${today.getDate().toString().padStart(2,'0')}.xlsx`;
    
    // Download file
    XLSX.writeFile(wb, filename);
}
</script>

</body>
</html>