<div class="col-md-2 bg-light vh-100 p-3">
    <h5>Menu</h5>
    <div class="list-group">
        <a href="../master/" class="list-group-item list-group-item-action">Master Data</a>
        <a href="../transaksi/" class="list-group-item list-group-item-action">Transaksi</a>
        <a href="../laporan/" class="list-group-item list-group-item-action">Laporan</a>
    </div>
</div>
<div class="col-md-10 p-4">
