<?php
session_start();
if(!isset($_SESSION['admin'])){
    header("Location: ../login.php");
    exit;
}

include "../config/database.php";

// Ambil username admin
$admin_id = $_SESSION['admin'];
$stmt = $conn->prepare("SELECT username FROM user_admin WHERE id=?");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();
$username = $admin['username'];

// ===== HAPUS =====
if(isset($_POST['delete'])){
    $kwitansi_id = intval($_POST['delete']);
    $stmt = $conn->prepare("DELETE FROM kwitansi WHERE kwitansi_id=?");
    $stmt->bind_param("i", $kwitansi_id);
    if($stmt->execute()){
        echo "<script>alert('Kwitansi berhasil dihapus!'); window.location.href='kwitansi.php';</script>";
    } else {
        echo "<script>alert('Gagal hapus: ".$stmt->error."'); window.location.href='kwitansi.php';</script>";
    }
    exit;
}

// ===== EDIT/UPDATE =====
if(isset($_POST['update'])){
    $kwitansi_id = intval($_POST['kwitansi_id']);
    $nomor_kwitansi = trim($_POST['nomor_kwitansi']);
    $invoice_id = intval($_POST['invoice_id']);
    $partner_penerima_id = intval($_POST['partner_penerima_id']); // Partner penerima
    $tanggal_kwitansi = $_POST['tanggal_kwitansi'];
    $ttd_id = !empty($_POST['ttd_id']) ? intval($_POST['ttd_id']) : null;

    // Ambil data dari invoice
    $stmt = $conn->prepare("
        SELECT i.po_id, i.partner_id, i.barang_id, i.kapal_id, 
               i.harga_id, i.ppn, i.total_biaya
        FROM invoice i
        WHERE i.invoice_id = ?
    ");
    $stmt->bind_param("i", $invoice_id);
    $stmt->execute();
    $inv_data = $stmt->get_result()->fetch_assoc();

    if(!$inv_data){
        echo "<script>alert('Data invoice tidak ditemukan!'); window.history.back();</script>";
        exit;
    }

    // Update kwitansi - gunakan partner_penerima_id untuk "Sudah Terima Dari"
    if($ttd_id !== null){
        $stmt = $conn->prepare("UPDATE kwitansi SET 
            nomor_kwitansi=?, invoice_id=?, po_id=?, tanggal_invoice=?, 
            partner_id=?, barang_id=?, kapal_id=?, harga_id=?, ppn=?, total_biaya=?, ttd_id=?
            WHERE kwitansi_id=?");
        $stmt->bind_param(
            "siisiiiiddii",
            $nomor_kwitansi, $invoice_id, $inv_data['po_id'], $tanggal_kwitansi,
            $partner_penerima_id, $inv_data['barang_id'], $inv_data['kapal_id'], 
            $inv_data['harga_id'], $inv_data['ppn'], $inv_data['total_biaya'], $ttd_id, $kwitansi_id
        );
    } else {
        $stmt = $conn->prepare("UPDATE kwitansi SET 
            nomor_kwitansi=?, invoice_id=?, po_id=?, tanggal_invoice=?, 
            partner_id=?, barang_id=?, kapal_id=?, harga_id=?, ppn=?, total_biaya=?, ttd_id=NULL
            WHERE kwitansi_id=?");
        $stmt->bind_param(
            "siisiiiiddi",
            $nomor_kwitansi, $invoice_id, $inv_data['po_id'], $tanggal_kwitansi,
            $partner_penerima_id, $inv_data['barang_id'], $inv_data['kapal_id'], 
            $inv_data['harga_id'], $inv_data['ppn'], $inv_data['total_biaya'], $kwitansi_id
        );
    }

    if($stmt->execute()){
        echo "<script>alert('Kwitansi berhasil diupdate!'); window.location.href='kwitansi.php';</script>";
    } else {
        echo "<script>alert('Gagal update: ".$stmt->error."'); window.history.back();</script>";
    }
    exit;
}

// ===== TAMBAH =====
if(isset($_POST['submit'])){
    $nomor_kwitansi = trim($_POST['nomor_kwitansi']);
    $invoice_id = intval($_POST['invoice_id']);
    $partner_penerima_id = intval($_POST['partner_penerima_id']); // Partner penerima
    $tanggal_kwitansi = $_POST['tanggal_kwitansi'];
    $ttd_id = !empty($_POST['ttd_id']) ? intval($_POST['ttd_id']) : null;

    // Ambil data dari invoice
    $stmt = $conn->prepare("
        SELECT i.po_id, i.partner_id, i.barang_id, i.kapal_id, 
               i.harga_id, i.ppn, i.total_biaya
        FROM invoice i
        WHERE i.invoice_id = ?
    ");
    $stmt->bind_param("i", $invoice_id);
    $stmt->execute();
    $inv_data = $stmt->get_result()->fetch_assoc();

    if(!$inv_data){
        echo "<script>alert('Data invoice tidak ditemukan!'); window.history.back();</script>";
        exit;
    }

    // Insert kwitansi - gunakan partner_penerima_id untuk "Sudah Terima Dari"
    if($ttd_id !== null){
        $stmt = $conn->prepare("INSERT INTO kwitansi 
            (nomor_kwitansi, invoice_id, po_id, tanggal_invoice, partner_id, barang_id, kapal_id, harga_id, ppn, total_biaya, ttd_id) 
            VALUES (?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param(
            "siisiiiiddi",
            $nomor_kwitansi, $invoice_id, $inv_data['po_id'], $tanggal_kwitansi,
            $partner_penerima_id, $inv_data['barang_id'], $inv_data['kapal_id'], 
            $inv_data['harga_id'], $inv_data['ppn'], $inv_data['total_biaya'], $ttd_id
        );
    } else {
        $stmt = $conn->prepare("INSERT INTO kwitansi 
            (nomor_kwitansi, invoice_id, po_id, tanggal_invoice, partner_id, barang_id, kapal_id, harga_id, ppn, total_biaya, ttd_id) 
            VALUES (?,?,?,?,?,?,?,?,?,?,NULL)");
        $stmt->bind_param(
            "siisiiiiddd",
            $nomor_kwitansi, $invoice_id, $inv_data['po_id'], $tanggal_kwitansi,
            $partner_penerima_id, $inv_data['barang_id'], $inv_data['kapal_id'], 
            $inv_data['harga_id'], $inv_data['ppn'], $inv_data['total_biaya']
        );
    }

    if($stmt->execute()){
        echo "<script>alert('Kwitansi berhasil ditambahkan!'); window.location.href='kwitansi.php';</script>";
    } else {
        echo "<script>alert('Gagal tambah: ".$stmt->error."'); window.history.back();</script>";
    }
    exit;
}

// Ambil data Kwitansi
$result = $conn->query("
    SELECT 
        k.*,
        kp.nama_kapal,
        p.nama_partner,
        b.nama_barang,
        po.nomor_po,
        i.nomor_invoice,
        GROUP_CONCAT(DISTINCT h.area SEPARATOR ', ') AS area_list
    FROM kwitansi k
    LEFT JOIN kapal kp ON k.kapal_id = kp.kapal_id
    LEFT JOIN partner p ON k.partner_id = p.partner_id
    LEFT JOIN barang b ON k.barang_id = b.barang_id
    LEFT JOIN purchase_order po ON k.po_id = po.po_id
    LEFT JOIN invoice i ON k.invoice_id = i.invoice_id
    LEFT JOIN sales_order so ON so.po_id = po.po_id
    LEFT JOIN harga h ON so.harga_id = h.harga_id
    GROUP BY k.kwitansi_id
    ORDER BY k.tanggal_invoice DESC
");

// Mode edit
$editRow = null;
if(isset($_GET['edit'])){
    $editId = intval($_GET['edit']);
    $stmt = $conn->prepare("
        SELECT k.*, i.nomor_invoice
        FROM kwitansi k
        LEFT JOIN invoice i ON k.invoice_id = i.invoice_id
        WHERE k.kwitansi_id=?
    ");
    $stmt->bind_param("i", $editId);
    $stmt->execute();
    $res = $stmt->get_result();
    $editRow = $res->fetch_assoc();
}

// Ambil data untuk dropdown
$invoice_list = $conn->query("
    SELECT i.invoice_id, i.nomor_invoice, i.tanggal_invoice, 
           po.nomor_po, po.uraian_pekerjaan
    FROM invoice i
    LEFT JOIN purchase_order po ON i.po_id = po.po_id
    WHERE NOT EXISTS (
        SELECT 1 FROM kwitansi k WHERE k.invoice_id = i.invoice_id
    )
    ORDER BY i.tanggal_invoice DESC
");

$partner_list = $conn->query("SELECT partner_id, nama_partner FROM partner ORDER BY nama_partner");
$ttd_list = $conn->query("SELECT ttd_id, nama, jabatan FROM ttd ORDER BY nama");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kwitansi Management</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    background: linear-gradient(135deg, #3e4e92ff 0%, #764ba2 100%);
    min-height: 100vh;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* ===== Sidebar ===== */
.main-content {
    margin-left: 0px;
    transition: all 0.3s ease;
}

.sidebar {
    position: fixed;
    top: 0;
    left: -320px;
    width: 320px;
    height: 100%;
    background: linear-gradient(180deg, #1e3c72 0%, #2a5298 100%);
    color: #fff;
    overflow-y: auto;
    transition: all 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    z-index: 1050;
    box-shadow: 4px 0 20px rgba(0, 0, 0, 0.3);
}

.sidebar::-webkit-scrollbar {
    width: 8px;
}

.sidebar::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.1);
}

.sidebar::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.3);
    border-radius: 10px;
}

.sidebar.active { 
    left: 0;
    box-shadow: 4px 0 30px rgba(0, 0, 0, 0.5);
}

.sidebar-header { 
    padding: 25px 20px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-bottom: 2px solid rgba(255, 255, 255, 0.1);
}

.sidebar-header h3 {
    font-size: 22px;
    font-weight: 700;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    letter-spacing: 0.5px;
}

.sidebar-menu { 
    list-style: none;
    padding: 15px 0;
    margin: 0;
}

.sidebar-menu li { 
    list-style: none;
    padding: 5px 15px;
    margin: 3px 0;
}

.sidebar-menu li a {
    color: #fff;
    text-decoration: none;
    display: flex;
    align-items: center;
    padding: 14px 18px;
    border-radius: 12px;
    transition: all 0.3s ease;
    font-size: 15px;
    font-weight: 500;
    position: relative;
    overflow: hidden;
}

.sidebar-menu li a::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 4px;
    background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
    transform: scaleY(0);
    transition: transform 0.3s ease;
}

.sidebar-menu li a:hover {
    background: rgba(255, 255, 255, 0.15);
    padding-left: 28px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}

.sidebar-menu li a:hover::before {
    transform: scaleY(1);
}

.sidebar-menu li a i {
    margin-right: 12px;
    font-size: 18px;
    width: 25px;
    text-align: center;
}

/* ===== Hamburger ===== */
.hamburger-btn {
    position: fixed;
    top: 10px;
    left: 18px;
    z-index: 1100;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border: none;
    color: #fff;
    padding: 12px 16px;
    font-size: 22px;
    cursor: pointer;
    border-radius: 12px;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
}

.hamburger-btn:hover {
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.4);
}

.hamburger-btn.shifted { 
    left: 335px;
}

/* ===== Overlay ===== */
#overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(3px);
    display: none;
    z-index: 1040;
    transition: all 0.3s ease;
}

#overlay.active { display: block; }

/* ===== Dropdown custom ===== */
.submenu { 
    display: none;
    padding-left: 20px;
    list-style: none;
    margin-top: 5px;
}

.submenu.active { 
    display: block !important;
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.submenu li a {
    padding: 10px 18px;
    font-size: 14px;
    background: rgba(255, 255, 255, 0.05);
    margin: 3px 0;
}

.arrow { 
    float: right;
    transition: transform 0.3s ease;
    font-size: 12px;
}

.arrow::before { 
    font-size: 11px;
}

.dropdown-toggle.active .arrow {
    transform: rotate(180deg);
}

.dropdown-toggle::after {
    display: none;
}

/* ===== Header ===== */
.header {
    position: sticky;
    top: 0;
    left: 0;
    right: 0;
    height: 80px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 30px;
    z-index: 1030;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
    backdrop-filter: blur(10px);
}

.header .title { 
    margin-left: 50px;
    font-size: 24px;
    font-weight: 700;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    letter-spacing: 0.5px;
}

.header .user-info { 
    font-size: 15px;
    display: flex;
    align-items: center;
    gap: 15px;
    font-weight: 500;
}

.header .user-info .username {
    padding: 8px 18px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 20px;
    backdrop-filter: blur(10px);
}

.header .user-info a.logout-btn {
    background: linear-gradient(135deg, #ff416c, #ff4b2b);
    color: #fff;
    padding: 10px 24px;
    border-radius: 25px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(52, 11, 21, 0.4);
    display: inline-block;
}

.header .user-info a.logout-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(255, 65, 108, 0.5);
    filter: brightness(1.1);
}

/* ===== Main Content ===== */
.container-fluid {
    padding: 30px;
}

/* ===== Card Styles ===== */
.card {
    border: none;
    border-radius: 18px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    background: rgba(255, 255, 255, 0.98);
    backdrop-filter: blur(10px);
    animation: fadeInUp 0.5s ease;
    margin-bottom: 30px;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.card-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    border: none;
    border-radius: 18px 18px 0 0 !important;
    padding: 20px 25px;
    color: white;
}

.card-header h5 {
    margin: 0;
    font-weight: 700;
    font-size: 20px;
    text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2);
}

.card-body {
    padding: 25px;
}

/* ===== Button Styles ===== */
.btn {
    border-radius: 10px;
    padding: 8px 20px;
    font-weight: 600;
    transition: all 0.3s ease;
    border: none;
}

.btn-success {
    background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
    color: #fff;
}

.btn-success:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(17, 153, 142, 0.4);
    filter: brightness(1.1);
}

.btn-danger {
    background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%);
    color: #fff;
}

.btn-danger:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(255, 65, 108, 0.4);
    filter: brightness(1.1);
}

.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
    filter: brightness(1.1);
}

.btn-secondary {
    background: linear-gradient(135deg, #868f96 0%, #596164 100%);
}

.btn-secondary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(134, 143, 150, 0.4);
    filter: brightness(1.1);
}

.btn-action {
    margin: 0 3px;
    font-size: 12px;
    padding: 4px 8px;
}

/* ===== Table Styles ===== */
.table-responsive {
    border-radius: 12px;
    overflow-x: auto;
    overflow-y: visible;
    -webkit-overflow-scrolling: touch;
}

.table {
    margin: 0;
    background: white;
}

.table thead th {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    font-weight: 600;
    border: none;
    padding: 12px 8px;
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.5px;
}

.table tbody tr {
    transition: all 0.3s ease;
}

.table tbody tr:hover {
    background: rgba(102, 126, 234, 0.1);
    transform: scale(1.002);
}

.table tbody td {
    padding: 12px 8px;
    vertical-align: middle;
}

.form-label {
    font-weight: 600;
    color: #2a5298;
    margin-bottom: 8px;
    font-size: 0.9rem;
}

.form-control, .form-select {
    border: 2px solid #e0e6ed;
    border-radius: 10px;
    padding: 10px 15px;
    transition: all 0.3s ease;
}

.form-control:focus, .form-select:focus {
    border-color: #667eea;
    box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
}

.detail-table {
    font-size: 13px;
}

.detail-table th {
    background: #f1f3f5;
    font-weight: 600;
}

.badge-area {
    background: #e7f3ff;
    color: #0066cc;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 11px;
}

/* ===== Responsive ===== */
@media (max-width: 768px) {
    .header .title {
        font-size: 18px;
        margin-left: 20px;
    }
    
    .hamburger-btn.shifted {
        left: 295px;
    }
    
    .sidebar {
        width: 280px;
        left: -280px;
    }
}
</style>
</head>
<body>

<!-- Hamburger Button -->
<button class="hamburger-btn" id="hamburgerBtn">
    <i class="fas fa-bars"></i>
</button>

<!-- Sidebar -->
<div id="sidebar" class="sidebar">
    <div class="sidebar-header">
        <h3><i class="fas fa-chart-line"></i> Dashboard Utama</h3>
    </div>
    <br>
    <ul class="sidebar-menu">
        <li><a href="../index.php"><i class="fas fa-home"></i> Dashboard</a></li>

        <li class="dropdown">
            <a href="#" class="dropdown-toggle"><i class="fas fa-database"></i> Master Data <span class="arrow"></span></a>
            <ul class="submenu">
                <li><a href="../master/partner.php"><i class="fas fa-handshake"></i> Partner</a></li>
                <li><a href="../master/ttd.php"><i class="fas fa-signature"></i> Tanda Tangan</a></li>
                <li><a href="../master/kendaraan.php"><i class="fas fa-truck"></i> Kendaraan</a></li>
                <li><a href="../master/barang.php"><i class="fas fa-box"></i> Barang</a></li>
                <li><a href="../master/dermaga.php"><i class="fas fa-anchor"></i> Dermaga</a></li>
                <li><a href="../master/harga.php"><i class="fas fa-dollar-sign"></i> Harga</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" class="dropdown-toggle"><i class="fas fa-exchange-alt"></i> Transaksi <span class="arrow"></span></a>
            <ul class="submenu">
                <li><a href="../transaksi/sales_order.php"><i class="fas fa-shopping-cart"></i> Sales Order</a></li>
                <li><a href="../transaksi/purchase_order.php"><i class="fas fa-shopping-bag"></i> Purchase Order</a></li>
                <li><a href="../transaksi/surat_jalan.php"><i class="fas fa-file-alt"></i> Surat Jalan</a></li>
            </ul>
        </li>
        
        <li class="dropdown">
            <a href="#" class="dropdown-toggle"><i class="fas fa-file-invoice"></i> Laporan <span class="arrow"></span></a>
            <ul class="submenu">
                <li><a href="../laporan/order_kerja.php"><i class="fas fa-clipboard-list"></i> Order Kerja</a></li>
                <li><a href="../laporan/invoice.php"><i class="fas fa-file-invoice-dollar"></i> Invoice</a></li>
                <li><a href="../laporan/kwitansi.php"><i class="fas fa-receipt"></i> Kwitansi</a></li>
                <li><a href="../laporan/laporan_realisasi.php"><i class="fas fa-chart-bar"></i> Realisasi</a></li>
            </ul>
        </li>

        <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</div>

<!-- Overlay -->
<div id="overlay"></div>

<!-- Header -->
<div class="header">
    <div class="title">Kwitansi Management</div>
    <div class="user-info">
        <span class="username"><i class="fas fa-user-circle"></i> <?= htmlspecialchars($username) ?></span>
        <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</div>

<div class="container-fluid main-content">
    <!-- Form Tambah/Edit Kwitansi -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">
                <i class="bi bi-receipt-<?= $editRow ? 'cutoff' : '' ?>"></i> 
                <?= $editRow ? 'Edit Kwitansi' : 'Form Kwitansi Baru' ?>
            </h5>
        </div>
        <div class="card-body">
            <form method="POST" id="formKwitansi">
                <?php if($editRow): ?>
                <input type="hidden" name="kwitansi_id" value="<?= $editRow['kwitansi_id'] ?>">
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Nomor Kwitansi <span class="text-danger">*</span></label>
                        <input type="text" name="nomor_kwitansi" class="form-control" 
                            value="<?= $editRow ? htmlspecialchars($editRow['nomor_kwitansi']) : '' ?>"
                            placeholder="0132/10/KEU/PK-TRANS/2025" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">No. Invoice <span class="text-danger">*</span></label>
                        <select name="invoice_id" id="invoice_id" class="form-select" required>
                            <option value="">-- Pilih Invoice --</option>
                            <?php 
                            $invoice_list->data_seek(0);
                            while($row = $invoice_list->fetch_assoc()): 
                            ?>
                                <option value="<?= $row['invoice_id'] ?>" 
                                    <?= ($editRow && $editRow['invoice_id'] == $row['invoice_id']) ? 'selected' : '' ?>
                                    data-nomor-po="<?= htmlspecialchars($row['nomor_po']) ?>"
                                    data-uraian="<?= htmlspecialchars($row['uraian_pekerjaan']) ?>">
                                    <?= htmlspecialchars($row['nomor_invoice']) ?> - (PO: <?= htmlspecialchars($row['nomor_po']) ?>)
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Tanggal Kwitansi <span class="text-danger">*</span></label>
                        <input type="date" name="tanggal_kwitansi" class="form-control" 
                            value="<?= $editRow ? $editRow['tanggal_invoice'] : date('Y-m-d') ?>" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Sudah Terima Dari <span class="text-danger">*</span></label>
                        <select name="partner_penerima_id" class="form-select" required>
                            <option value="">-- Pilih Partner Penerima --</option>
                            <?php 
                            $partner_list->data_seek(0); 
                            while($row = $partner_list->fetch_assoc()): 
                            ?>
                                <option value="<?= $row['partner_id'] ?>"
                                    <?= ($editRow && $editRow['partner_id'] == $row['partner_id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($row['nama_partner']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                        <small class="text-muted">Partner yang tertera di bagian "Sudah Terima Dari"</small>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Tanda Tangan (Direktur)</label>
                        <select name="ttd_id" class="form-select">
                            <option value="">-- Pilih Tanda Tangan --</option>
                            <?php 
                            $ttd_list->data_seek(0); 
                            while($row = $ttd_list->fetch_assoc()): 
                            ?>
                                <option value="<?= $row['ttd_id'] ?>"
                                    <?= ($editRow && $editRow['ttd_id'] == $row['ttd_id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($row['nama']) ?> - <?= htmlspecialchars($row['jabatan']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Preview Detail</label>
                    <div id="previewDetail" class="border rounded p-3 bg-light">
                        <p class="text-muted text-center">Pilih Invoice untuk melihat detail</p>
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <?php if($editRow): ?>
                    <button type="submit" name="update" class="btn btn-success">
                        <i class="bi bi-save"></i> Update Kwitansi
                    </button>
                    <a href="kwitansi.php" class="btn btn-secondary">
                        <i class="bi bi-x-circle"></i> Batal
                    </a>
                    <?php else: ?>
                    <button type="submit" name="submit" class="btn btn-primary">
                        <i class="bi bi-save"></i> Simpan Kwitansi
                    </button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <!-- Daftar Kwitansi -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0"><i class="bi bi-list-ul"></i> Daftar Kwitansi</h5>
        </div>
<div class="card-body">
    <div class="row mb-3">
        <div class="col-md-8">
            <input type="text" id="searchKwitansi" class="form-control" placeholder="🔍 Cari nomor kwitansi, invoice, PO, kapal...">
        </div>
        <div class="col-md-4 text-end">
            <button onclick="exportToExcel()" class="btn btn-success">
                <i class="bi bi-file-earmark-excel"></i> Export ke Excel
            </button>
        </div>
    </div>

            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th width="20">No</th>
                            <th>No. Kwitansi</th>
                            <th>No. Invoice</th>
                            <th>No. PO</th>
                            <th>Tanggal</th>
                            <th>Sudah Terima Dari</th>
                            <th>Kapal</th>
                            <th>Barang</th>
                            <th>Area</th>
                            <th>Total Biaya</th>
                            <th width="100">Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="kwitansiTable">
                        <?php if($result && $result->num_rows > 0): 
                            $no = 1;
                            while($row = $result->fetch_assoc()): 
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><strong class="text-primary"><?= htmlspecialchars($row['nomor_kwitansi']) ?></strong></td>
                            <td><?= htmlspecialchars($row['nomor_invoice']) ?></td>
                            <td><?= htmlspecialchars($row['nomor_po']) ?></td>
                            <td><?= date('d/m/Y', strtotime($row['tanggal_invoice'])) ?></td>
                            <td><?= htmlspecialchars($row['nama_partner']) ?></td>
                            <td><?= htmlspecialchars($row['nama_kapal']) ?></td>
                            <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                            <td><span class="badge-area"><?= htmlspecialchars($row['area_list'] ?? '-') ?></span></td>
                            <td>Rp <?= number_format($row['total_biaya'], 2, ',', '.') ?></td>
                            <td>
                                <a href="cetak_kwitansi.php?kwitansi_id=<?= $row['kwitansi_id'] ?>&print=1" target="_blank" class="btn btn-sm btn-success btn-action">
                                    <i class="bi bi-printer"></i> Cetak
                                </a>
                                <form method="POST" style="display:inline;" onsubmit="return confirm('Yakin hapus kwitansi ini?')">
                                    <input type="hidden" name="delete" value="<?= $row['kwitansi_id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-danger btn-action">
                                        <i class="bi bi-trash"></i> Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; else: ?>
                        <tr>
                            <td colspan="11" class="text-center text-muted">Tidak ada data kwitansi</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

<script>
// Sidebar Toggle
const hamburger = document.getElementById('hamburgerBtn');
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');

hamburger.addEventListener('click',()=>{ 
    sidebar.classList.toggle('active'); 
    overlay.classList.toggle('active'); 
    hamburger.classList.toggle('shifted'); 
});

overlay.addEventListener('click', ()=>{ 
    sidebar.classList.remove('active'); 
    overlay.classList.remove('active'); 
    hamburger.classList.remove('shifted'); 
});

// Dropdown submenu
document.querySelectorAll('.dropdown-toggle').forEach(toggle=>{
    toggle.addEventListener('click', function(e){
        e.preventDefault();
        this.classList.toggle('active');
        const submenu = this.nextElementSibling;
        if(submenu){ submenu.classList.toggle('active'); }
    });
});

// Preview Invoice Details - Load on page load if editing
<?php if($editRow): ?>
window.addEventListener('DOMContentLoaded', function() {
    loadPreview(<?= $editRow['invoice_id'] ?>);
});
<?php endif; ?>

// Preview Invoice Details
document.getElementById('invoice_id').addEventListener('change', function() {
    loadPreview(this.value);
});

async function loadPreview(invoiceId) {
    const preview = document.getElementById('previewDetail');
    
    if(!invoiceId) {
        preview.innerHTML = '<p class="text-muted text-center">Pilih Invoice untuk melihat detail</p>';
        return;
    }
    
    preview.innerHTML = '<p class="text-center"><i class="bi bi-hourglass-split"></i> Memuat data...</p>';
    
    try {
        const response = await fetch('get_invoice_detail.php?invoice_id=' + invoiceId);
        const data = await response.json();
        
        if(data.success) {
            let html = `
                <div class="mb-3 p-2">
                    <table class="table table-sm detail-table mb-0">
                        <tr><th width="150">No. Invoice:</th><td>${data.data.nomor_invoice}</td></tr>
                        <tr><th>No. PO:</th><td>${data.data.nomor_po}</td></tr>
                        <tr><th>Partner:</th><td>${data.data.partner}</td></tr>
                        <tr><th>Kapal:</th><td>${data.data.kapal}</td></tr>
                        <tr><th>Barang:</th><td>${data.data.barang}</td></tr>
                        <tr><th>Periode:</th><td>${data.data.periode}</td></tr>
                        <tr><th>Total Tonase:</th><td>${data.data.total_tonase} Ton</td></tr>
                        <tr><th>Subtotal:</th><td>Rp ${data.data.subtotal}</td></tr>
                        <tr><th>PPN (${data.data.ppn}%):</th><td>Rp ${data.data.ppn_nominal}</td></tr>
                        <tr><th class="text-primary">Total Biaya:</th><td class="text-primary fw-bold">Rp ${data.data.total_biaya}</td></tr>
                    </table>
                </div>
            `;
            preview.innerHTML = html;
        } else {
            preview.innerHTML = '<p class="text-danger">Gagal memuat data: ' + (data.message || 'Unknown error') + '</p>';
        }
    } catch(e) {
        preview.innerHTML = '<p class="text-danger">Error: ' + e.message + '</p>';
    }
}

// Search Kwitansi
document.getElementById('searchKwitansi').addEventListener('keyup', function() {
    const filter = this.value.toLowerCase();
    const rows = document.querySelectorAll('#kwitansiTable tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(filter) ? '' : 'none';
    });
});

function exportToExcel() {
    // Ambil data dari tabel
    const table = document.querySelector('#kwitansiTable').closest('table');
    const rows = [];
    
    // Header
    const headers = ['No', 'No. Kwitansi', 'No. Invoice', 'No. PO', 'Tanggal', 'Sudah Terima Dari', 'Kapal', 'Barang', 'Area', 'Total Biaya'];
    rows.push(headers);
    
    // Data rows (hanya yang visible)
    const tableRows = document.querySelectorAll('#kwitansiTable tr');
    tableRows.forEach((row, index) => {
        if (row.style.display !== 'none' && row.cells.length > 1) {
            const rowData = [
                row.cells[0].textContent.trim(),
                row.cells[1].textContent.trim(),
                row.cells[2].textContent.trim(),
                row.cells[3].textContent.trim(),
                row.cells[4].textContent.trim(),
                row.cells[5].textContent.trim(),
                row.cells[6].textContent.trim(),
                row.cells[7].textContent.trim(),
                row.cells[8].textContent.trim(),
                row.cells[9].textContent.replace('Rp ', '').trim()
            ];
            rows.push(rowData);
        }
    });
    
    // Buat workbook dan worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(rows);
    
    // Set column widths
    ws['!cols'] = [
        { wch: 5 },  // No
        { wch: 30 }, // No. Kwitansi
        { wch: 20 }, // No. Invoice
        { wch: 20 }, // No. PO
        { wch: 12 }, // Tanggal
        { wch: 25 }, // Sudah Terima Dari
        { wch: 25 }, // Kapal
        { wch: 20 }, // Barang
        { wch: 20 }, // Area
        { wch: 20 }  // Total Biaya
    ];
    
    // Add worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Kwitansi');
    
    // Generate filename dengan tanggal
    const today = new Date();
    const filename = `Kwitansi_${today.getFullYear()}${(today.getMonth()+1).toString().padStart(2,'0')}${today.getDate().toString().padStart(2,'0')}.xlsx`;
    
    // Download file
    XLSX.writeFile(wb, filename);
}
</script>

</body>
</html>