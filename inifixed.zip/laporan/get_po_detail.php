<?php
session_start();
if(!isset($_SESSION['admin'])){
    echo json_encode(['success'=>false, 'message'=>'Unauthorized']);
    exit;
}

include "../config/database.php";

$po_id = intval($_GET['po_id']);

// Ambil semua SO terkait PO beserta area
$stmt = $conn->prepare("
    SELECT 
        so.so_id,
        so.barang_id,
        so.kapal_id,
        so.harga_id,
        so.partner_id,
        h.harga,
        h.area,
        k.nama_kapal,
        b.nama_barang,
        p.nama_partner,
        po.periode
    FROM sales_order so
    JOIN harga h ON so.harga_id = h.harga_id
    JOIN kapal k ON so.kapal_id = k.kapal_id
    JOIN barang b ON so.barang_id = b.barang_id
    JOIN partner p ON so.partner_id = p.partner_id
    JOIN purchase_order po ON so.po_id = po.po_id
    WHERE so.po_id = ?
");
$stmt->bind_param("i", $po_id);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows == 0){
    echo json_encode(['success'=>false, 'message'=>'PO tidak ditemukan']);
    exit;
}

// Siapkan array data untuk response
$data = [];
$total_est = 0;

while($row = $result->fetch_assoc()){
    // Hitung tonase berdasarkan warehouse_id yang sesuai dengan area dari harga_id
    // Pertama, ambil warehouse_id dari tabel harga berdasarkan area
    $stmt_warehouse = $conn->prepare("
        SELECT tujuan_id 
        FROM harga 
        WHERE harga_id = ? AND tujuan_tipe = 'warehouse'
    ");
    $stmt_warehouse->bind_param("i", $row['harga_id']);
    $stmt_warehouse->execute();
    $warehouse_data = $stmt_warehouse->get_result()->fetch_assoc();
    $warehouse_id = $warehouse_data['tujuan_id'] ?? null;

    // Hitung tonase dari surat_jalan yang sesuai dengan kapal, barang, dan warehouse
    if($warehouse_id){
        $stmt2 = $conn->prepare("
            SELECT SUM(sj.tonase) AS total_tonase
            FROM surat_jalan sj
            WHERE sj.kapal_id = ? 
            AND sj.barang_id = ? 
            AND sj.warehouse_id = ?
        ");
        $stmt2->bind_param("iii", $row['kapal_id'], $row['barang_id'], $warehouse_id);
    } else {
        // Fallback jika tidak ada warehouse_id
        $stmt2 = $conn->prepare("
            SELECT SUM(sj.tonase) AS total_tonase
            FROM surat_jalan sj
            WHERE sj.kapal_id = ? 
            AND sj.barang_id = ?
        ");
        $stmt2->bind_param("ii", $row['kapal_id'], $row['barang_id']);
    }
    
    $stmt2->execute();
    $tonase_data = $stmt2->get_result()->fetch_assoc();
    $tonase = floatval($tonase_data['total_tonase'] ?? 0);

    $subtotal = $tonase * floatval($row['harga']);
    $total_est += $subtotal;

    $data[] = [
        'area' => $row['area'] ?? '-',
        'kapal' => $row['nama_kapal'],
        'barang' => $row['nama_barang'],
        'partner' => $row['nama_partner'],
        'periode' => $row['periode'],
        'tonase' => number_format($tonase, 3, ',', '.'),
        'harga' => number_format($row['harga'], 0, ',', '.'),
        'estimasi_total' => number_format($subtotal, 0, ',', '.')
    ];
}

echo json_encode([
    'success' => true,
    'data' => $data,
    'total_est' => number_format($total_est, 0, ',', '.')
]);
?>