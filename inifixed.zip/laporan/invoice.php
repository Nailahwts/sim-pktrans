<?php
session_start();
if(!isset($_SESSION['admin'])){
    header("Location: ../login.php");
    exit;
}

include "../config/database.php";

// Ambil username admin
$admin_id = $_SESSION['admin'];
$stmt = $conn->prepare("SELECT username FROM user_admin WHERE id=?");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();
$username = $admin['username'];
// ===== HAPUS =====
if (isset($_POST['delete'])) {
    // aktifkan agar mysqli lempar exception
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    $invoice_id = intval($_POST['delete']);

    try {
        $stmt = $conn->prepare("DELETE FROM invoice WHERE invoice_id = ?");
        $stmt->bind_param("i", $invoice_id);

        if ($stmt->execute()) {
            echo "<script>
                alert('Invoice berhasil dihapus!');
                window.location.href='invoice.php';
            </script>";
        }

        $stmt->close();

    } catch (mysqli_sql_exception $e) {
        // deteksi error foreign key
        if (strpos($e->getMessage(), 'foreign key constraint fails') !== false) {
            echo "<script>
                alert('Tidak dapat dihapus karena masih ada kwitansi terkait.\\nSilakan hapus kwitansi terlebih dahulu.');
                window.location.href='invoice.php';
            </script>";
        } else {
            // tampilkan pesan kesalahan lain (opsional)
            $error_message = addslashes($e->getMessage());
            echo "<script>
                alert('Gagal hapus data. Error: {$error_message}');
                window.location.href='invoice.php';
            </script>";
        }
    }

    exit;
}

// ===== EDIT/UPDATE =====
if(isset($_POST['update'])){
    $invoice_id = intval($_POST['invoice_id']);
    $nomor_invoice = trim($_POST['nomor_invoice']);
    $po_id = intval($_POST['po_id']);
    $tanggal_invoice = $_POST['tanggal_invoice'];
    $ppn = floatval($_POST['ppn']);
    $ttd_id = !empty($_POST['ttd_id']) ? intval($_POST['ttd_id']) : null;

    // Ambil semua SO terkait PO
    $stmt = $conn->prepare("
        SELECT so.partner_id, so.barang_id, so.kapal_id, so.harga_id
        FROM sales_order so
        WHERE so.po_id = ?
    ");
    $stmt->bind_param("i", $po_id);
    $stmt->execute();
    $so_result = $stmt->get_result();

    if($so_result->num_rows == 0){
        echo "<script>alert('Data PO tidak ditemukan!'); window.history.back();</script>";
        exit;
    }

    // Hitung total tonase dari semua SO berdasarkan warehouse per area
    $total_tonase = 0;
    $partner_id = $barang_id = $kapal_id = $harga_id = null;
    
    while($so = $so_result->fetch_assoc()){
        $partner_id = $so['partner_id'];
        $barang_id = $so['barang_id'];
        $kapal_id = $so['kapal_id'];
        $harga_id = $so['harga_id'];

        // Ambil warehouse_id dari harga
        $stmt_wh = $conn->prepare("SELECT tujuan_id FROM harga WHERE harga_id = ? AND tujuan_tipe = 'warehouse'");
        $stmt_wh->bind_param("i", $harga_id);
        $stmt_wh->execute();
        $wh_data = $stmt_wh->get_result()->fetch_assoc();
        $warehouse_id = $wh_data['tujuan_id'] ?? null;

        // Hitung tonase berdasarkan warehouse
        if($warehouse_id){
            $stmt2 = $conn->prepare("
                SELECT SUM(sj.tonase) AS tonase
                FROM surat_jalan sj
                WHERE sj.kapal_id=? AND sj.barang_id=? AND sj.warehouse_id=?
            ");
            $stmt2->bind_param("iii", $kapal_id, $barang_id, $warehouse_id);
        } else {
            $stmt2 = $conn->prepare("
                SELECT SUM(sj.tonase) AS tonase
                FROM surat_jalan sj
                WHERE sj.kapal_id=? AND sj.barang_id=?
            ");
            $stmt2->bind_param("ii", $kapal_id, $barang_id);
        }
        
        $stmt2->execute();
        $sj_data = $stmt2->get_result()->fetch_assoc();
        $total_tonase += floatval($sj_data['tonase'] ?? 0);
    }

// ===== Hitung subtotal per area =====
$subtotal = 0;

$stmt = $conn->prepare("
    SELECT so.harga_id, h.area, h.harga, h.tujuan_id
    FROM sales_order so
    JOIN harga h ON so.harga_id = h.harga_id
    WHERE so.po_id = ?
");
$stmt->bind_param("i", $po_id);
$stmt->execute();
$harga_result = $stmt->get_result();

while ($row_h = $harga_result->fetch_assoc()) {
    $harga_id = $row_h['harga_id'];
    $harga_satuan = floatval($row_h['harga']);
    $warehouse_id = $row_h['tujuan_id'];

    // Hitung tonase untuk area/warehouse ini
    if ($warehouse_id) {
        $stmt2 = $conn->prepare("
            SELECT SUM(sj.tonase) AS tonase
            FROM surat_jalan sj
            WHERE sj.kapal_id=? AND sj.barang_id=? AND sj.warehouse_id=?
        ");
        $stmt2->bind_param("iii", $kapal_id, $barang_id, $warehouse_id);
    } else {
        $stmt2 = $conn->prepare("
            SELECT SUM(sj.tonase) AS tonase
            FROM surat_jalan sj
            WHERE sj.kapal_id=? AND sj.barang_id=?
        ");
        $stmt2->bind_param("ii", $kapal_id, $barang_id);
    }

    $stmt2->execute();
    $sj_data = $stmt2->get_result()->fetch_assoc();
    $tonase_area = floatval($sj_data['tonase'] ?? 0);

    // Subtotal area = tonase × harga
    $subtotal += $tonase_area * $harga_satuan;
}

// ===== Hitung total dan PPN =====
$ppn_nominal = ($subtotal * $ppn) / 100;
$total_biaya = $subtotal + $ppn_nominal;


    // Update invoice - PERBAIKAN: ttd_id bisa NULL
    if($ttd_id !== null){
        $stmt = $conn->prepare("UPDATE invoice SET 
            nomor_invoice=?, po_id=?, tanggal_invoice=?, partner_id=?, barang_id=?, 
            kapal_id=?, harga_id=?, total_tonase=?, ppn=?, total_biaya=?, ttd_id=?
            WHERE invoice_id=?");
        $stmt->bind_param(
            "sisiiiiddiii",
            $nomor_invoice,
            $po_id,
            $tanggal_invoice,
            $partner_id,
            $barang_id,
            $kapal_id,
            $harga_id,
            $total_tonase,
            $ppn,
            $total_biaya,
            $ttd_id,
            $invoice_id
        );
    } else {
        $stmt = $conn->prepare("UPDATE invoice SET 
            nomor_invoice=?, po_id=?, tanggal_invoice=?, partner_id=?, barang_id=?, 
            kapal_id=?, harga_id=?, total_tonase=?, ppn=?, total_biaya=?, ttd_id=NULL
            WHERE invoice_id=?");
        $stmt->bind_param(
            "sisiiiiddi",
            $nomor_invoice,
            $po_id,
            $tanggal_invoice,
            $partner_id,
            $barang_id,
            $kapal_id,
            $harga_id,
            $total_tonase,
            $ppn,
            $total_biaya,
            $invoice_id
        );
    }

    if($stmt->execute()){
        echo "<script>alert('Invoice berhasil diupdate!'); window.location.href='invoice.php';</script>";
    } else {
        echo "<script>alert('Gagal update: ".$stmt->error."'); window.history.back();</script>";
    }
    exit;
}

// ===== TAMBAH =====
if(isset($_POST['submit'])){
    $nomor_invoice = trim($_POST['nomor_invoice']);
    $po_id = intval($_POST['po_id']);
    $tanggal_invoice = $_POST['tanggal_invoice'];
    $ppn = floatval($_POST['ppn']);
    $ttd_id = !empty($_POST['ttd_id']) ? intval($_POST['ttd_id']) : null;

    // Ambil semua SO terkait PO
    $stmt = $conn->prepare("
        SELECT so.partner_id, so.barang_id, so.kapal_id, so.harga_id
        FROM sales_order so
        WHERE so.po_id = ?
    ");
    $stmt->bind_param("i", $po_id);
    $stmt->execute();
    $so_result = $stmt->get_result();

    if($so_result->num_rows == 0){
        echo "<script>alert('Data PO tidak ditemukan!'); window.history.back();</script>";
        exit;
    }

    $total_tonase = 0;
    $partner_id = $barang_id = $kapal_id = $harga_id = null;
    
    while($so = $so_result->fetch_assoc()){
        $partner_id = $so['partner_id'];
        $barang_id = $so['barang_id'];
        $kapal_id = $so['kapal_id'];
        $harga_id = $so['harga_id'];

        // Ambil warehouse_id dari harga
        $stmt_wh = $conn->prepare("SELECT tujuan_id FROM harga WHERE harga_id = ? AND tujuan_tipe = 'warehouse'");
        $stmt_wh->bind_param("i", $harga_id);
        $stmt_wh->execute();
        $wh_data = $stmt_wh->get_result()->fetch_assoc();
        $warehouse_id = $wh_data['tujuan_id'] ?? null;

        // Hitung tonase berdasarkan warehouse
        if($warehouse_id){
            $stmt2 = $conn->prepare("
                SELECT SUM(sj.tonase) AS tonase
                FROM surat_jalan sj
                WHERE sj.kapal_id=? AND sj.barang_id=? AND sj.warehouse_id=?
            ");
            $stmt2->bind_param("iii", $kapal_id, $barang_id, $warehouse_id);
        } else {
            $stmt2 = $conn->prepare("
                SELECT SUM(sj.tonase) AS tonase
                FROM surat_jalan sj
                WHERE sj.kapal_id=? AND sj.barang_id=?
            ");
            $stmt2->bind_param("ii", $kapal_id, $barang_id);
        }
        
        $stmt2->execute();
        $sj_data = $stmt2->get_result()->fetch_assoc();
        $total_tonase += floatval($sj_data['tonase'] ?? 0);
    }

    // Ambil harga
    $stmt = $conn->prepare("SELECT harga FROM harga WHERE harga_id = ?");
    $stmt->bind_param("i", $harga_id);
    $stmt->execute();
    $harga_data = $stmt->get_result()->fetch_assoc();
    $harga_satuan = floatval($harga_data['harga'] ?? 0);

    $subtotal = $total_tonase * $harga_satuan;
    $ppn_nominal = ($subtotal * $ppn) / 100;
    $total_biaya = $subtotal + $ppn_nominal;

    // PERBAIKAN: Handle ttd_id yang NULL
    if($ttd_id !== null){
        $stmt = $conn->prepare("INSERT INTO invoice 
            (nomor_invoice, po_id, tanggal_invoice, partner_id, barang_id, kapal_id, harga_id, total_tonase, ppn, total_biaya, ttd_id) 
            VALUES (?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param(
            "sisiiiidddi",
            $nomor_invoice,
            $po_id,
            $tanggal_invoice,
            $partner_id,
            $barang_id,
            $kapal_id,
            $harga_id,
            $total_tonase,
            $ppn,
            $total_biaya,
            $ttd_id
        );
    } else {
        $stmt = $conn->prepare("INSERT INTO invoice 
            (nomor_invoice, po_id, tanggal_invoice, partner_id, barang_id, kapal_id, harga_id, total_tonase, ppn, total_biaya, ttd_id) 
            VALUES (?,?,?,?,?,?,?,?,?,?,NULL)");
        $stmt->bind_param(
            "sisiiiiddd",
            $nomor_invoice,
            $po_id,
            $tanggal_invoice,
            $partner_id,
            $barang_id,
            $kapal_id,
            $harga_id,
            $total_tonase,
            $ppn,
            $total_biaya
        );
    }

    if($stmt->execute()){
        echo "<script>alert('Invoice berhasil ditambahkan!'); window.location.href='invoice.php';</script>";
    } else {
        echo "<script>alert('Gagal tambah: ".$stmt->error."'); window.history.back();</script>";
    }
    exit;
}

// Ambil data Invoice
$result = $conn->query("
    SELECT 
        i.*,
        k.nama_kapal,
        p.nama_partner,
        b.nama_barang,
        po.nomor_po,
        GROUP_CONCAT(DISTINCT h.area SEPARATOR ', ') AS area_list
    FROM invoice i
    LEFT JOIN kapal k ON i.kapal_id = k.kapal_id
    LEFT JOIN partner p ON i.partner_id = p.partner_id
    LEFT JOIN barang b ON i.barang_id = b.barang_id
    LEFT JOIN purchase_order po ON i.po_id = po.po_id
    LEFT JOIN sales_order so ON so.po_id = po.po_id
    LEFT JOIN harga h ON so.harga_id = h.harga_id
    GROUP BY i.invoice_id
    ORDER BY i.tanggal_invoice DESC
");


// Mode edit
$editRow = null;
if(isset($_GET['edit'])){
    $editId = intval($_GET['edit']);
    $stmt = $conn->prepare("
        SELECT i.*, po.nomor_po
        FROM invoice i
        LEFT JOIN purchase_order po ON i.po_id = po.po_id
        WHERE i.invoice_id=?
    ");
    $stmt->bind_param("i", $editId);
    $stmt->execute();
    $res = $stmt->get_result();
    $editRow = $res->fetch_assoc();
}

// Ambil data untuk dropdown
$po_list = $conn->query("
    SELECT DISTINCT po.po_id, po.nomor_po, po.uraian_pekerjaan, po.periode
    FROM purchase_order po
    WHERE po.terima_po = 127
    ORDER BY po.tanggal_po DESC
");
$ttd_list = $conn->query("SELECT ttd_id, nama, jabatan FROM ttd ORDER BY nama");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Invoice Management</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    background: linear-gradient(135deg, #3e4e92ff 0%, #764ba2 100%);
    min-height: 100vh;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* ===== Sidebar ===== */
.main-content {
    margin-left: 0px;
    transition: all 0.3s ease;
}

.sidebar {
    position: fixed;
    top: 0;
    left: -320px;
    width: 320px;
    height: 100%;
    background: linear-gradient(180deg, #1e3c72 0%, #2a5298 100%);
    color: #fff;
    overflow-y: auto;
    transition: all 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    z-index: 1050;
    box-shadow: 4px 0 20px rgba(0, 0, 0, 0.3);
}

.sidebar::-webkit-scrollbar {
    width: 8px;
}

.sidebar::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.1);
}

.sidebar::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.3);
    border-radius: 10px;
}

.sidebar.active { 
    left: 0;
    box-shadow: 4px 0 30px rgba(0, 0, 0, 0.5);
}

.sidebar-header { 
    padding: 25px 20px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-bottom: 2px solid rgba(255, 255, 255, 0.1);
}

.sidebar-header h3 {
    font-size: 22px;
    font-weight: 700;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    letter-spacing: 0.5px;
}

.sidebar-menu { 
    list-style: none;
    padding: 15px 0;
    margin: 0;
}

.sidebar-menu li { 
    list-style: none;
    padding: 5px 15px;
    margin: 3px 0;
}

.sidebar-menu li a {
    color: #fff;
    text-decoration: none;
    display: flex;
    align-items: center;
    padding: 14px 18px;
    border-radius: 12px;
    transition: all 0.3s ease;
    font-size: 15px;
    font-weight: 500;
    position: relative;
    overflow: hidden;
}

.sidebar-menu li a::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 4px;
    background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
    transform: scaleY(0);
    transition: transform 0.3s ease;
}

.sidebar-menu li a:hover {
    background: rgba(255, 255, 255, 0.15);
    padding-left: 28px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}

.sidebar-menu li a:hover::before {
    transform: scaleY(1);
}

.sidebar-menu li a i {
    margin-right: 12px;
    font-size: 18px;
    width: 25px;
    text-align: center;
}

/* ===== Hamburger ===== */
.hamburger-btn {
    position: fixed;
    top: 10px;
    left: 18px;
    z-index: 1100;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border: none;
    color: #fff;
    padding: 12px 16px;
    font-size: 22px;
    cursor: pointer;
    border-radius: 12px;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
}

.hamburger-btn:hover {
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.4);
}

.hamburger-btn.shifted { 
    left: 335px;
}

/* ===== Overlay ===== */
#overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(3px);
    display: none;
    z-index: 1040;
    transition: all 0.3s ease;
}

#overlay.active { display: block; }

/* ===== Dropdown custom ===== */
.submenu { 
    display: none;
    padding-left: 20px;
    list-style: none;
    margin-top: 5px;
}

.submenu.active { 
    display: block !important;
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.submenu li a {
    padding: 10px 18px;
    font-size: 14px;
    background: rgba(255, 255, 255, 0.05);
    margin: 3px 0;
}

.arrow { 
    float: right;
    transition: transform 0.3s ease;
    font-size: 12px;
}

.arrow::before { 
    font-size: 11px;
}

.dropdown-toggle.active .arrow {
    transform: rotate(180deg);
}

.dropdown-toggle::after {
    display: none;
}

/* ===== Header ===== */
.header {
    position: sticky;
    top: 0;
    left: 0;
    right: 0;
    height: 80px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 30px;
    z-index: 1030;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
    backdrop-filter: blur(10px);
}

.header .title { 
    margin-left: 50px;
    font-size: 24px;
    font-weight: 700;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    letter-spacing: 0.5px;
}

.header .user-info { 
    font-size: 15px;
    display: flex;
    align-items: center;
    gap: 15px;
    font-weight: 500;
}

.header .user-info .username {
    padding: 8px 18px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 20px;
    backdrop-filter: blur(10px);
}

.header .user-info a.logout-btn {
    background: linear-gradient(135deg, #ff416c, #ff4b2b);
    color: #fff;
    padding: 10px 24px;
    border-radius: 25px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(52, 11, 21, 0.4);
    display: inline-block;
}

.header .user-info a.logout-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(255, 65, 108, 0.5);
    filter: brightness(1.1);
}

/* ===== Main Content ===== */
.container-fluid {
    padding: 30px;
}

/* ===== Card Styles ===== */
.card {
    border: none;
    border-radius: 18px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    background: rgba(255, 255, 255, 0.98);
    backdrop-filter: blur(10px);
    animation: fadeInUp 0.5s ease;
    margin-bottom: 30px;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.card-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    border: none;
    border-radius: 18px 18px 0 0 !important;
    padding: 20px 25px;
    color: white;
}

.card-header h5 {
    margin: 0;
    font-weight: 700;
    font-size: 20px;
    text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2);
}

.card-body {
    padding: 25px;
}

/* ===== Button Styles ===== */
.btn {
    border-radius: 10px;
    padding: 8px 20px;
    font-weight: 600;
    transition: all 0.3s ease;
    border: none;
}

.btn-success {
    background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
    color: #fff;
}

.btn-success:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(17, 153, 142, 0.4);
    filter: brightness(1.1);
}

.btn-danger {
    background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%);
    color: #fff;
}

.btn-danger:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(255, 65, 108, 0.4);
    filter: brightness(1.1);
}

.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
    filter: brightness(1.1);
}

.btn-secondary {
    background: linear-gradient(135deg, #868f96 0%, #596164 100%);
}

.btn-secondary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(134, 143, 150, 0.4);
    filter: brightness(1.1);
}

.btn-action {
    margin: 0 3px;
    font-size: 12px;
    padding: 4px 8px;
}

/* ===== Table Styles ===== */
.table-responsive {
    border-radius: 12px;
    overflow-x: auto;
    overflow-y: visible;
    -webkit-overflow-scrolling: touch;
}

.table {
    margin: 0;
    background: white;
}

.table thead th {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    font-weight: 600;
    border: none;
    padding: 12px 8px;
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.5px;
}

.table tbody tr {
    transition: all 0.3s ease;
}

.table tbody tr:hover {
    background: rgba(102, 126, 234, 0.1);
    transform: scale(1.002);
}

.table tbody td {
    padding: 12px 8px;
    vertical-align: middle;
}

.form-label {
    font-weight: 600;
    color: #2a5298;
    margin-bottom: 8px;
    font-size: 0.9rem;
}

.form-control, .form-select {
    border: 2px solid #e0e6ed;
    border-radius: 10px;
    padding: 10px 15px;
    transition: all 0.3s ease;
}

.form-control:focus, .form-select:focus {
    border-color: #667eea;
    box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
}

.detail-table {
    font-size: 13px;
}

.detail-table th {
    background: #f1f3f5;
    font-weight: 600;
}

.badge-area {
    background: #e7f3ff;
    color: #0066cc;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 11px;
}

/* ===== Responsive ===== */
@media (max-width: 768px) {
    .header .title {
        font-size: 18px;
        margin-left: 20px;
    }
    
    .hamburger-btn.shifted {
        left: 295px;
    }
    
    .sidebar {
        width: 280px;
        left: -280px;
    }
}
</style>
</head>
<body>

<!-- Hamburger Button -->
<button class="hamburger-btn" id="hamburgerBtn">
    <i class="fas fa-bars"></i>
</button>

<!-- Sidebar -->
<div id="sidebar" class="sidebar">
    <div class="sidebar-header">
        <h3><i class="fas fa-chart-line"></i> Dashboard Utama</h3>
    </div>
    <br>
    <ul class="sidebar-menu">
        <li><a href="../index.php"><i class="fas fa-home"></i> Dashboard</a></li>

        <li class="dropdown">
            <a href="#" class="dropdown-toggle"><i class="fas fa-database"></i> Master Data <span class="arrow"></span></a>
            <ul class="submenu">
                <li><a href="../master/partner.php"><i class="fas fa-handshake"></i> Partner</a></li>
                <li><a href="../master/ttd.php"><i class="fas fa-signature"></i> Tanda Tangan</a></li>
                <li><a href="../master/kendaraan.php"><i class="fas fa-truck"></i> Kendaraan</a></li>
                <li><a href="../master/barang.php"><i class="fas fa-box"></i> Barang</a></li>
                <li><a href="../master/dermaga.php"><i class="fas fa-anchor"></i> Dermaga</a></li>
                <li><a href="../master/harga.php"><i class="fas fa-dollar-sign"></i> Harga</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" class="dropdown-toggle"><i class="fas fa-exchange-alt"></i> Transaksi <span class="arrow"></span></a>
            <ul class="submenu">
                <li><a href="../transaksi/sales_order.php"><i class="fas fa-shopping-cart"></i> Sales Order</a></li>
                <li><a href="../transaksi/purchase_order.php"><i class="fas fa-shopping-bag"></i> Purchase Order</a></li>
                <li><a href="../transaksi/surat_jalan.php"><i class="fas fa-file-alt"></i> Surat Jalan</a></li>
            </ul>
        </li>
        
        <li class="dropdown">
            <a href="#" class="dropdown-toggle"><i class="fas fa-file-invoice"></i> Laporan <span class="arrow"></span></a>
            <ul class="submenu">
                <li><a href="../laporan/order_kerja.php"><i class="fas fa-clipboard-list"></i> Order Kerja</a></li>
                <li><a href="../laporan/invoice.php"><i class="fas fa-file-invoice-dollar"></i> Invoice</a></li>
                <li><a href="../laporan/kwitansi.php"><i class="fas fa-receipt"></i> Kwitansi</a></li>
                <li><a href="../laporan/laporan_realisasi.php"><i class="fas fa-chart-bar"></i> Realisasi</a></li>
            </ul>
        </li>

        <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</div>

<!-- Overlay -->
<div id="overlay"></div>

<!-- Header -->
<div class="header">
    <div class="title">Invoice Management</div>
    <div class="user-info">
        <span class="username"><i class="fas fa-user-circle"></i> <?= htmlspecialchars($username) ?></span>
        <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</div>

<div class="container-fluid main-content">
    <!-- Form Tambah/Edit Invoice -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">
                <i class="bi bi-file-earmark-<?= $editRow ? 'text' : 'plus' ?>"></i> 
                <?= $editRow ? 'Edit Invoice' : 'Form Invoice Baru' ?>
            </h5>
        </div>
        <div class="card-body">
            <form method="POST" id="formInvoice">
                <?php if($editRow): ?>
                <input type="hidden" name="invoice_id" value="<?= $editRow['invoice_id'] ?>">
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Nomor Invoice <span class="text-danger">*</span></label>
                        <input type="text" name="nomor_invoice" class="form-control" 
                            value="<?= $editRow ? htmlspecialchars($editRow['nomor_invoice']) : '' ?>"
                            placeholder="INV/2025/001" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">No. PO <span class="text-danger">*</span></label>
                        <select name="po_id" id="po_id" class="form-select" required>
                            <option value="">-- Pilih Purchase Order --</option>
                            <?php 
                            $po_list->data_seek(0);
                            while($row = $po_list->fetch_assoc()): 
                            ?>
                                <option value="<?= $row['po_id'] ?>" 
                                    <?= ($editRow && $editRow['po_id'] == $row['po_id']) ? 'selected' : '' ?>
                                    data-uraian="<?= htmlspecialchars($row['uraian_pekerjaan']) ?>"
                                    data-periode="<?= htmlspecialchars($row['periode']) ?>">
                                    <?= htmlspecialchars($row['nomor_po']) ?> - <?= htmlspecialchars($row['uraian_pekerjaan']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Tanggal Invoice <span class="text-danger">*</span></label>
                        <input type="date" name="tanggal_invoice" class="form-control" 
                            value="<?= $editRow ? $editRow['tanggal_invoice'] : date('Y-m-d') ?>" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">PPN (%)</label>
                        <input type="number" name="ppn" id="ppn" class="form-control" step="0.01" 
                            value="<?= $editRow ? $editRow['ppn'] : '11' ?>" placeholder="Masukkan persentase PPN">
                        <small class="text-muted">Contoh: 11 untuk PPN 11%</small>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Tanda Tangan (Hormat Kami)</label>
                        <select name="ttd_id" class="form-select">
                            <option value="">-- Pilih Tanda Tangan --</option>
                            <?php 
                            $ttd_list->data_seek(0); 
                            while($row = $ttd_list->fetch_assoc()): 
                            ?>
                                <option value="<?= $row['ttd_id'] ?>"
                                    <?= ($editRow && $editRow['ttd_id'] == $row['ttd_id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($row['nama']) ?> - <?= htmlspecialchars($row['jabatan']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Preview Detail</label>
                    <div id="previewDetail" class="border rounded p-3 bg-light">
                        <p class="text-muted text-center">Pilih Invoice untuk melihat detail</p>
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <?php if($editRow): ?>
                    <button type="submit" name="update" class="btn btn-success">
                        <i class="bi bi-save"></i> Update Invoice
                    </button>
                    <a href="invoice.php" class="btn btn-secondary">
                        <i class="bi bi-x-circle"></i> Batal
                    </a>
                    <?php else: ?>
                    <button type="submit" name="submit" class="btn btn-primary">
                        <i class="bi bi-save"></i> Simpan Invoice
                    </button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <!-- Daftar Invoice -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0"><i class="bi bi-list-ul"></i> Daftar Invoice</h5>
        </div>
<div class="card-body">
    <div class="row mb-3">
        <div class="col-md-8">
            <input type="text" id="searchInvoice" class="form-control" placeholder="🔍 Cari nomor invoice, PO, kapal...">
        </div>
        <div class="col-md-4 text-end">
            <button onclick="exportToExcel()" class="btn btn-success">
                <i class="bi bi-file-earmark-excel"></i> Export ke Excel
            </button>
        </div>
    </div>

            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th width="20">No</th>
                            <th>No. Invoice</th>
                            <th>No. PO</th>
                            <th>Tanggal</th>
                            <th>Kapal</th>
                            <th>Barang</th>
                            <th>Area</th>
                            <th>Total Tonase</th>
                            <th>PPN %</th>
                            <th>Total Biaya</th>
                            <th width="100">Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="invoiceTable">
                        <?php if($result && $result->num_rows > 0): 
                            $no = 1;
                            while($row = $result->fetch_assoc()): 
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><strong class="text-primary"><?= htmlspecialchars($row['nomor_invoice']) ?></strong></td>
                            <td><?= htmlspecialchars($row['nomor_po']) ?></td>
                            <td><?= date('d/m/Y', strtotime($row['tanggal_invoice'])) ?></td>
                            <td><?= htmlspecialchars($row['nama_kapal']) ?></td>
                            <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                            <td><span class="badge-area"><?= htmlspecialchars($row['area_list'] ?? '-') ?></span></td>
                            <td><?= number_format($row['total_tonase'], 3, ',', '.') ?></td>
                            <td><?= number_format($row['ppn'], 2, ',', '.') ?>%</td>
                            <td>Rp <?= number_format($row['total_biaya'], 2, ',', '.') ?></td>
                            <td>
                                <a href="cetak_invoice.php?invoice_id=<?= $row['invoice_id'] ?>&print=1" target="_blank" class="btn btn-sm btn-success btn-action">
                                    <i class="bi bi-printer"></i> Cetak
                                </a>
                                <form method="POST" style="display:inline;" onsubmit="return confirm('Yakin hapus invoice ini?')">
                                    <input type="hidden" name="delete" value="<?= $row['invoice_id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-danger btn-action">
                                        <i class="bi bi-trash"></i> Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; else: ?>
                        <tr>
                            <td colspan="11" class="text-center text-muted">Tidak ada data invoice</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

<script>
// Sidebar Toggle
const hamburger = document.getElementById('hamburgerBtn');
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');

hamburger.addEventListener('click',()=>{ 
    sidebar.classList.toggle('active'); 
    overlay.classList.toggle('active'); 
    hamburger.classList.toggle('shifted'); 
});

overlay.addEventListener('click', ()=>{ 
    sidebar.classList.remove('active'); 
    overlay.classList.remove('active'); 
    hamburger.classList.remove('shifted'); 
});

// Dropdown submenu
document.querySelectorAll('.dropdown-toggle').forEach(toggle=>{
    toggle.addEventListener('click', function(e){
        e.preventDefault();
        this.classList.toggle('active');
        const submenu = this.nextElementSibling;
        if(submenu){ submenu.classList.toggle('active'); }
    });
});

// Preview PO Details - Load on page load if editing
<?php if($editRow): ?>
window.addEventListener('DOMContentLoaded', function() {
    loadPreview(<?= $editRow['po_id'] ?>);
});
<?php endif; ?>

// Preview PO Details
document.getElementById('po_id').addEventListener('change', function() {
    loadPreview(this.value);
});

async function loadPreview(poId) {
    const preview = document.getElementById('previewDetail');
    
    if(!poId) {
        preview.innerHTML = '<p class="text-muted text-center">Pilih Invoice untuk melihat detail</p>';
        return;
    }
    
    preview.innerHTML = '<p class="text-center"><i class="bi bi-hourglass-split"></i> Memuat data...</p>';
    
    try {
        const response = await fetch('get_po_detail.php?po_id=' + poId);
        const data = await response.json();
        
        if(data.success) {
            let html = '';
            data.data.forEach(item => {
                html += `
                    <div class="mb-3 p-2 border-bottom">
                        <table class="table table-sm detail-table mb-0">
                            <tr><th width="150">Area:</th><td>${item.area}</td></tr>
                            <tr><th>Kapal:</th><td>${item.kapal}</td></tr>
                            <tr><th>Barang:</th><td>${item.barang}</td></tr>
                            <tr><th>Partner:</th><td>${item.partner}</td></tr>
                            <tr><th>Periode:</th><td>${item.periode}</td></tr>
                            <tr><th>Total Tonase:</th><td>${item.tonase} Ton</td></tr>
                            <tr><th>Harga Satuan:</th><td>Rp ${item.harga}</td></tr>
                            <tr><th class="text-primary">Estimasi Total:</th><td class="text-primary fw-bold">Rp ${item.estimasi_total}</td></tr>
                        </table>
                    </div>
                `;
            });
            html += `<p class="fw-bold text-end mt-2">Total Keseluruhan: Rp ${data.total_est}</p>`;
            preview.innerHTML = html;
        } else {
            preview.innerHTML = '<p class="text-danger">Gagal memuat data: ' + (data.message || 'Unknown error') + '</p>';
        }
    } catch(e) {
        preview.innerHTML = '<p class="text-danger">Error: ' + e.message + '</p>';
    }
}

// Search Invoice
document.getElementById('searchInvoice').addEventListener('keyup', function() {
    const filter = this.value.toLowerCase();
    const rows = document.querySelectorAll('#invoiceTable tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(filter) ? '' : 'none';
    });
});

function exportToExcel() {
    // Ambil data dari tabel
    const table = document.querySelector('#invoiceTable').closest('table');
    const rows = [];
    
    // Header
    const headers = ['No', 'No. Invoice', 'No. PO', 'Tanggal', 'Kapal', 'Barang', 'Area', 'Total Tonase', 'PPN %', 'Total Biaya'];
    rows.push(headers);
    
    // Data rows (hanya yang visible)
    const tableRows = document.querySelectorAll('#invoiceTable tr');
    tableRows.forEach((row, index) => {
        if (row.style.display !== 'none' && row.cells.length > 1) {
            const rowData = [
                row.cells[0].textContent.trim(),
                row.cells[1].textContent.trim(),
                row.cells[2].textContent.trim(),
                row.cells[3].textContent.trim(),
                row.cells[4].textContent.trim(),
                row.cells[5].textContent.trim(),
                row.cells[6].textContent.trim(),
                row.cells[7].textContent.trim(),
                row.cells[8].textContent.trim(),
                row.cells[9].textContent.replace('Rp ', '').trim()
            ];
            rows.push(rowData);
        }
    });
    
    // Buat workbook dan worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(rows);
    
    // Set column widths
    ws['!cols'] = [
        { wch: 5 },  // No
        { wch: 20 }, // No. Invoice
        { wch: 20 }, // No. PO
        { wch: 12 }, // Tanggal
        { wch: 25 }, // Kapal
        { wch: 20 }, // Barang
        { wch: 20 }, // Area
        { wch: 15 }, // Total Tonase
        { wch: 10 }, // PPN %
        { wch: 20 }  // Total Biaya
    ];
    
    // Add worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Invoice');
    
    // Generate filename dengan tanggal
    const today = new Date();
    const filename = `Invoice_${today.getFullYear()}${(today.getMonth()+1).toString().padStart(2,'0')}${today.getDate().toString().padStart(2,'0')}.xlsx`;
    
    // Download file
    XLSX.writeFile(wb, filename);
}
</script>

</body>
</html>