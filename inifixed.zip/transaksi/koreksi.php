<?php
session_start();
if(!isset($_SESSION['admin'])){
    header("Location: ../login.php");
    exit;
}

require_once '../config/database.php';

// Ambil username admin
$admin_id = $_SESSION['admin'];
$stmt = $conn->prepare("SELECT username FROM user_admin WHERE id=?");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();
$username = $admin['username'];

// Proses simpan data koreksi
if(isset($_POST['submit_koreksi'])){
    $tanggal_arr = $_POST['tanggal'];
    $shift_arr = $_POST['shift'];
    $warehouse_arr = $_POST['warehouse_id'];
    $barang_arr = $_POST['barang_id'];
    $kapal_arr = $_POST['kapal_id'];
    $koreksi_arr = $_POST['tonase_koreksi'];

    $stmt = $conn->prepare(
        "INSERT INTO koreksi_tonase 
            (tanggal, shift, warehouse_id, barang_id, kapal_id, tonase_koreksi) 
        VALUES (?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            tonase_koreksi = VALUES(tonase_koreksi)"
    );

    $successCount = 0;
    $errorCount = 0;

    foreach($koreksi_arr as $key => $tonase_koreksi){
        if($tonase_koreksi !== '' && $tonase_koreksi !== null){
            $tanggal = $tanggal_arr[$key];
            $shift = intval($shift_arr[$key]);
            $warehouse_id = intval($warehouse_arr[$key]);
            $barang_id = intval($barang_arr[$key]);
            $kapal_id = intval($kapal_arr[$key]);
            $tonase_koreksi_val = floatval($tonase_koreksi);

            $stmt->bind_param("siiiid", 
                $tanggal, $shift, $warehouse_id, $barang_id, $kapal_id, $tonase_koreksi_val
            );
            
            if($stmt->execute()){
                $successCount++;
            } else {
                $errorCount++;
            }
        }
    }
    $stmt->close();
    
    $message = "Berhasil menyimpan $successCount data koreksi.";
    if($errorCount > 0){
        $message .= "\\nAda $errorCount data gagal disimpan.";
    }
    
    echo "<script>alert('$message');window.location='koreksi.php';</script>";
    exit;
}

// Query utama untuk mengambil data totalan
$sqlGrouped = "
    SELECT 
        sj.tanggal, 
        sj.shift, 
        sj.warehouse_id, 
        sj.barang_id, 
        sj.kapal_id,
        b.nama_barang,
        k.nama_kapal,
        w.nama_warehouse,
        SUM(sj.tonase) as total_tonase,
        kt.tonase_koreksi
    FROM surat_jalan sj
    JOIN barang b ON sj.barang_id = b.barang_id
    JOIN kapal k ON sj.kapal_id = k.kapal_id
    JOIN warehouse w ON sj.warehouse_id = w.warehouse_id
    LEFT JOIN koreksi_tonase kt ON 
        sj.tanggal = kt.tanggal AND
        sj.shift = kt.shift AND
        sj.warehouse_id = kt.warehouse_id AND
        sj.barang_id = kt.barang_id AND
        sj.kapal_id = kt.kapal_id
    GROUP BY 
        sj.tanggal, 
        sj.shift, 
        sj.warehouse_id, 
        sj.barang_id, 
        sj.kapal_id,
        b.nama_barang,
        k.nama_kapal,
        w.nama_warehouse,
        kt.tonase_koreksi
    ORDER BY 
        w.nama_warehouse,
        sj.tanggal DESC, 
        k.nama_kapal, 
        sj.shift;
";

$groupedResult = $conn->query($sqlGrouped);

?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Koreksi Tonase</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <title>Koreksi Tonase</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>

<style>
    .total-row {
        background-color: #ffeb3b !important;
        font-weight: bold;
        font-size: 1.1em;
    }
    .warehouse-total-row {
        background-color: #fff9c4 !important;
        font-weight: bold;
    }
    .text-danger {
        color: #dc3545 !important;
    }
    .text-success {
        color: #198754 !important;
    }
    .summary-card {
        border: 2px solid #ffeb3b;
    }
    .summary-table th {
        background-color: #ffeb3b !important;
        color: #000;
    }
    .modal-lg-custom {
        max-width: 900px;
    }
</style>
</head>

<body>

<button class="hamburger-btn" id="hamburgerBtn">
    <i class="fas fa-bars"></i>
</button>

<div id="overlay"></div>

<div class="header">
    <div class="title">Koreksi Tonase</div>
    <div class="user-info">
        <span class="username"><i class="fas fa-user-circle"></i> <?= htmlspecialchars($username) ?></span>
        <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</div>

<div class="container-fluid main-content">

    <div class="card mb-3">
        <div class="card-header bg-warning text-dark d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-edit"></i> Input Koreksi Tonase</h5>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#summaryModal">
                <i class="bi bi-eye"></i> Lihat Koreksi
            </button>
        </div>
        <div class="card-body">
            <div class="alert alert-info">
                <i class="bi bi-info-circle"></i> Halaman ini menampilkan total tonase dari Surat Jalan, dikelompokkan berdasarkan Tanggal, Shift, dan Warehouse.
                <br>
                <i class="bi bi-pencil-square"></i> Masukkan nilai tonase koreksi di kolom "PETROPORT (Koreksi)" dan klik "Simpan Koreksi" di bagian bawah.
            </div>

            <form method="POST" id="formKoreksi">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover table-striped table-sm" id="koreksiTable">
                        <thead class="table-dark">
                            <tr>
                                <th>BARANG</th>
                                <th>KAPAL</th>
                                <th>TANGGAL</th>
                                <th>SHIFT</th>
                                <th>WAREHOUSE</th>
                                <th>REALISASI</th>
                                <th>PETROPORT</th>
                                <th>SELISIH</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($groupedResult->num_rows > 0): ?>
                                <?php while($row = $groupedResult->fetch_assoc()): ?>
                                    <?php
                                        $tonase_koreksi = $row['tonase_koreksi'] !== null ? floatval($row['tonase_koreksi']) : 0;
                                        $total_tonase = floatval($row['total_tonase']);
                                        $selisih = $total_tonase - $tonase_koreksi;
                                        if ($row['tonase_koreksi'] === null) {
                                            $selisih = 0;
                                        }
                                    ?>
                                    <tr class="data-row" data-warehouse="<?= htmlspecialchars($row['nama_warehouse']) ?>" data-warehouse-id="<?= $row['warehouse_id'] ?>">
                                        <input type="hidden" name="tanggal[]" value="<?= $row['tanggal'] ?>">
                                        <input type="hidden" name="shift[]" value="<?= $row['shift'] ?>">
                                        <input type="hidden" name="warehouse_id[]" value="<?= $row['warehouse_id'] ?>">
                                        <input type="hidden" name="barang_id[]" value="<?= $row['barang_id'] ?>">
                                        <input type="hidden" name="kapal_id[]" value="<?= $row['kapal_id'] ?>">
                                        
                                        <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                                        <td><?= htmlspecialchars($row['nama_kapal']) ?></td>
                                        <td><?= date('d/m/Y', strtotime($row['tanggal'])) ?></td>
                                        <td class="text-center"><?= $row['shift'] ?></td>
                                        <td><?= htmlspecialchars($row['nama_warehouse']) ?></td>
                                        
                                        <td class="text-end">
                                            <input type="number" class="form-control-plaintext text-end total-tonase" 
                                                   value="<?= number_format($total_tonase, 3, '.', '') ?>" readonly>
                                        </td>
                                        
                                        <td>
                                            <input type="number" name="tonase_koreksi[]" class="form-control tonase-koreksi" 
                                                   step="0.001" 
                                                   value="<?= $row['tonase_koreksi'] !== null ? number_format($row['tonase_koreksi'], 3, '.', '') : '' ?>" 
                                                   placeholder="0.000">
                                        </td>
                                        
                                        <td class="text-end">
                                            <input type="number" class="form-control-plaintext text-end selisih" 
                                                   value="<?= number_format($selisih, 3, '.', '') ?>" readonly>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center">Belum ada data surat jalan untuk dikoreksi.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr class="total-row">
                                <td colspan="5" class="text-center"><strong>TOTAL</strong></td>
                                <td class="text-end"><strong id="totalRealisasi">0.000</strong></td>
                                <td class="text-end"><strong id="totalPetroport">-</strong></td>
                                <td class="text-end"><strong id="totalSelisih">-</strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <div class="mt-3">
                    <button type="submit" name="submit_koreksi" class="btn btn-success">
                        <i class="bi bi-save"></i> Simpan Koreksi
                    </button>
                    <a href="koreksi.php" class="btn btn-secondary">
                        <i class="bi bi-arrow-counterclockwise"></i> Reset
                    </a>
                </div>
                <div class="mt-3">
    <button type="submit" name="submit_koreksi" class="btn btn-success">
        <i class="bi bi-save"></i> Simpan Koreksi
    </button>
    <a href="koreksi.php" class="btn btn-secondary">
        <i class="bi bi-arrow-counterclockwise"></i> Reset
    </a>

    <button type="button" id="exportExcelBtn" class="btn btn-info">
        <i class="bi bi-file-earmark-excel"></i> Export Excel
    </button>
    <button type="button" id="cetakPdfBtn" class="btn btn-danger">
        <i class="bi bi-file-earmark-pdf"></i> Cetak PDF
    </button>
    </div>
            </form>
        </div>
    </div>

</div>

<!-- Modal Summary -->
<div class="modal fade" id="summaryModal" tabindex="-1" aria-labelledby="summaryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg-custom">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title" id="summaryModalLabel"><i class="bi bi-bar-chart-fill"></i> Ringkasan Koreksi Tonase</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="card summary-card mb-3">
                    <div class="card-body">
                        <h6 class="card-title mb-3"><i class="bi bi-building"></i> Total Per Warehouse</h6>
                        <div class="table-responsive">
                            <table class="table table-bordered table-sm summary-table">
                                <thead>
                                    <tr>
                                        <th>WAREHOUSE</th>
                                        <th class="text-end">REALISASI</th>
                                        <th class="text-end">PETROPORT</th>
                                        <th class="text-end">SELISIH</th>
                                    </tr>
                                </thead>
                                <tbody id="warehouseSummaryBody">
                                    <!-- Diisi oleh JavaScript -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="card summary-card">
                    <div class="card-body">
                        <h6 class="card-title mb-3"><i class="bi bi-calculator"></i> Total Keseluruhan</h6>
                        <div class="table-responsive">
                            <table class="table table-bordered table-sm summary-table">
                                <thead>
                                    <tr>
                                        <th>TOTAL</th>
                                        <th class="text-end">REALISASI</th>
                                        <th class="text-end">PETROPORT</th>
                                        <th class="text-end">SELISIH</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="total-row">
                                        <td><strong>GRAND TOTAL</strong></td>
                                        <td class="text-end"><strong id="modalTotalRealisasi">0.000</strong></td>
                                        <td class="text-end"><strong id="modalTotalPetroport">-</strong></td>
                                        <td class="text-end"><strong id="modalTotalSelisih">-</strong></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Hamburger toggle
const hamburger = document.getElementById('hamburgerBtn');
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');

function openSidebar(){ 
    sidebar.classList.add('active'); 
    overlay.classList.add('active'); 
    hamburger.classList.add('shifted'); 
}

function closeSidebar(){ 
    sidebar.classList.remove('active'); 
    overlay.classList.remove('active'); 
    hamburger.classList.remove('shifted'); 
}

hamburger.addEventListener('click',()=>{ 
    sidebar.classList.contains('active') ? closeSidebar() : openSidebar(); 
});

overlay.addEventListener('click', closeSidebar);

// Dropdown toggle
document.querySelectorAll('.dropdown-toggle').forEach(toggle=>{
    toggle.addEventListener('click', function(e){
        e.preventDefault();
        this.classList.toggle('active');
        const submenu = this.nextElementSibling;
        if(submenu){ submenu.classList.toggle('active'); }
    });
});

// --- LOGIKA KALKULASI SELISIH DAN TOTAL ---

function calculateSelisih(inputElement) {
    const row = inputElement.closest('tr');
    if (!row) return;
    
    const totalTonaseInput = row.querySelector('.total-tonase');
    const selisihInput = row.querySelector('.selisih');
    
    const totalTonase = parseFloat(totalTonaseInput.value) || 0;
    const tonaseKoreksi = parseFloat(inputElement.value) || 0;
    
    let selisih = 0;
    
    if (inputElement.value !== '') {
        selisih = totalTonase - tonaseKoreksi;
    }

    selisihInput.value = selisih.toFixed(3);
    
    selisihInput.classList.remove('text-danger', 'text-success');
    if (selisih > 0) {
        selisihInput.classList.add('text-success');
    } else if (selisih < 0) {
        selisihInput.classList.add('text-danger');
    }
    
    updateTotals();
}

function updateTotals() {
    let totalRealisasi = 0;
    let totalPetroport = 0;
    let totalSelisih = 0;
    let hasPetroport = false;
    
    const dataRows = document.querySelectorAll('.data-row');
    
    dataRows.forEach(row => {
        const realisasiInput = row.querySelector('.total-tonase');
        const petroportInput = row.querySelector('.tonase-koreksi');
        const selisihInput = row.querySelector('.selisih');
        
        const realisasi = parseFloat(realisasiInput.value) || 0;
        const petroport = parseFloat(petroportInput.value) || 0;
        const selisih = parseFloat(selisihInput.value) || 0;
        
        totalRealisasi += realisasi;
        
        if (petroportInput.value !== '') {
            totalPetroport += petroport;
            totalSelisih += selisih;
            hasPetroport = true;
        }
    });
    
    document.getElementById('totalRealisasi').textContent = totalRealisasi.toFixed(3);
    
    if (hasPetroport) {
        document.getElementById('totalPetroport').textContent = totalPetroport.toFixed(3);
        
        const totalSelisihElement = document.getElementById('totalSelisih');
        totalSelisihElement.textContent = '(' + Math.abs(totalSelisih).toFixed(3) + ')';
        
        totalSelisihElement.classList.remove('text-danger', 'text-success');
        if (totalSelisih > 0) {
            totalSelisihElement.classList.add('text-success');
        } else if (totalSelisih < 0) {
            totalSelisihElement.classList.add('text-danger');
        }
    } else {
        document.getElementById('totalPetroport').textContent = '-';
        document.getElementById('totalSelisih').textContent = '-';
    }
}

function updateModalSummary() {
    const warehouseData = {};
    let grandTotalRealisasi = 0;
    let grandTotalPetroport = 0;
    let grandTotalSelisih = 0;
    let hasAnyPetroport = false;
    
    const dataRows = document.querySelectorAll('.data-row');
    
    dataRows.forEach(row => {
        const warehouseName = row.dataset.warehouse;
        const realisasiInput = row.querySelector('.total-tonase');
        const petroportInput = row.querySelector('.tonase-koreksi');
        const selisihInput = row.querySelector('.selisih');
        
        const realisasi = parseFloat(realisasiInput.value) || 0;
        const petroport = parseFloat(petroportInput.value) || 0;
        const selisih = parseFloat(selisihInput.value) || 0;
        
        if (!warehouseData[warehouseName]) {
            warehouseData[warehouseName] = {
                realisasi: 0,
                petroport: 0,
                selisih: 0,
                hasPetroport: false
            };
        }
        
        warehouseData[warehouseName].realisasi += realisasi;
        grandTotalRealisasi += realisasi;
        
        if (petroportInput.value !== '') {
            warehouseData[warehouseName].petroport += petroport;
            warehouseData[warehouseName].selisih += selisih;
            warehouseData[warehouseName].hasPetroport = true;
            
            grandTotalPetroport += petroport;
            grandTotalSelisih += selisih;
            hasAnyPetroport = true;
        }
    });
    
    // Update warehouse summary table
    const summaryBody = document.getElementById('warehouseSummaryBody');
    summaryBody.innerHTML = '';
    
    for (const [warehouse, data] of Object.entries(warehouseData)) {
        const row = document.createElement('tr');
        row.className = 'warehouse-total-row';
        
        let petroportDisplay = '-';
        let selisihDisplay = '-';
        let selisihClass = '';
        
        if (data.hasPetroport) {
            petroportDisplay = data.petroport.toFixed(3);
            selisihDisplay = '(' + Math.abs(data.selisih).toFixed(3) + ')';
            selisihClass = data.selisih > 0 ? 'text-success' : (data.selisih < 0 ? 'text-danger' : '');
        }
        
        row.innerHTML = `
            <td><strong>${warehouse}</strong></td>
            <td class="text-end">${data.realisasi.toFixed(3)}</td>
            <td class="text-end">${petroportDisplay}</td>
            <td class="text-end ${selisihClass}">${selisihDisplay}</td>
        `;
        
        summaryBody.appendChild(row);
    }
    
    // Update grand total
    document.getElementById('modalTotalRealisasi').textContent = grandTotalRealisasi.toFixed(3);
    
    if (hasAnyPetroport) {
        document.getElementById('modalTotalPetroport').textContent = grandTotalPetroport.toFixed(3);
        
        const modalTotalSelisihElement = document.getElementById('modalTotalSelisih');
        modalTotalSelisihElement.textContent = '(' + Math.abs(grandTotalSelisih).toFixed(3) + ')';
        
        modalTotalSelisihElement.classList.remove('text-danger', 'text-success');
        if (grandTotalSelisih > 0) {
            modalTotalSelisihElement.classList.add('text-success');
        } else if (grandTotalSelisih < 0) {
            modalTotalSelisihElement.classList.add('text-danger');
        }
    } else {
        document.getElementById('modalTotalPetroport').textContent = '-';
        document.getElementById('modalTotalSelisih').textContent = '-';
    }
}

// Event listener untuk modal
document.getElementById('summaryModal').addEventListener('show.bs.modal', function() {
    updateModalSummary();
});

// Ambil semua input koreksi
const koreksiInputs = document.querySelectorAll('.tonase-koreksi');

koreksiInputs.forEach(input => {
    calculateSelisih(input);
    
    input.addEventListener('input', function() {
        calculateSelisih(this);
    });
});

updateTotals();
</script>

</body>
</html>