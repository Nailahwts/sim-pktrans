<?php
session_start();
if(!isset($_SESSION['admin'])){
    header("Location: ../login.php");
    exit;
}

require_once '../config/database.php';

// Ambil username admin
$admin_id = $_SESSION['admin'];
$stmt = $conn->prepare("SELECT username FROM user_admin WHERE id=?");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();
$username = $admin['username'];

// Proses simpan data koreksi
if(isset($_POST['submit_koreksi'])){
    $tanggal_arr = $_POST['tanggal'];
    $shift_arr = $_POST['shift'];
    $warehouse_arr = $_POST['warehouse_id'];
    $barang_arr = $_POST['barang_id'];
    $kapal_arr = $_POST['kapal_id'];
    $koreksi_arr = $_POST['tonase_koreksi'];

    $stmt = $conn->prepare(
        "INSERT INTO koreksi_tonase 
            (tanggal, shift, warehouse_id, barang_id, kapal_id, tonase_koreksi) 
        VALUES (?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            tonase_koreksi = VALUES(tonase_koreksi)"
    );

    $successCount = 0;
    $errorCount = 0;

    foreach($koreksi_arr as $key => $tonase_koreksi){
        if($tonase_koreksi !== '' && $tonase_koreksi !== null){
            $tanggal = $tanggal_arr[$key];
            $shift = intval($shift_arr[$key]);
            $warehouse_id = intval($warehouse_arr[$key]);
            $barang_id = intval($barang_arr[$key]);
            $kapal_id = intval($kapal_arr[$key]);
            $tonase_koreksi_val = floatval($tonase_koreksi);

            $stmt->bind_param("siiiid", 
                $tanggal, $shift, $warehouse_id, $barang_id, $kapal_id, $tonase_koreksi_val
            );
            
            if($stmt->execute()){
                $successCount++;
            } else {
                $errorCount++;
            }
        }
    }
    $stmt->close();
    
    $message = "Berhasil menyimpan $successCount data koreksi.";
    if($errorCount > 0){
        $message .= "\\nAda $errorCount data gagal disimpan.";
    }
    
    echo "<script>alert('$message');window.location='koreksi.php';</script>";
    exit;
}

// Query utama untuk mengambil data totalan
$sqlGrouped = "
    SELECT 
        sj.tanggal, 
        sj.shift, 
        sj.warehouse_id, 
        sj.barang_id, 
        sj.kapal_id,
        b.nama_barang,
        k.nama_kapal,
        w.nama_warehouse,
        SUM(sj.tonase) as total_tonase,
        kt.tonase_koreksi
    FROM surat_jalan sj
    JOIN barang b ON sj.barang_id = b.barang_id
    JOIN kapal k ON sj.kapal_id = k.kapal_id
    JOIN warehouse w ON sj.warehouse_id = w.warehouse_id
    LEFT JOIN koreksi_tonase kt ON 
        sj.tanggal = kt.tanggal AND
        sj.shift = kt.shift AND
        sj.warehouse_id = kt.warehouse_id AND
        sj.barang_id = kt.barang_id AND
        sj.kapal_id = kt.kapal_id
    GROUP BY 
        sj.tanggal, 
        sj.shift, 
        sj.warehouse_id, 
        sj.barang_id, 
        sj.kapal_id,
        b.nama_barang,
        k.nama_kapal,
        w.nama_warehouse,
        kt.tonase_koreksi
    ORDER BY 
        w.nama_warehouse,
        sj.tanggal DESC, 
        k.nama_kapal, 
        sj.shift;
";

$groupedResult = $conn->query($sqlGrouped);

?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Koreksi Tonase</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <title>Koreksi Tonase</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>


<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    background: linear-gradient(135deg, #3e4e92ff 0%, #764ba2 100%);
    min-height: 100vh;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* ===== Sidebar ===== */
.main-content {
    margin-left: 0px;
    transition: all 0.3s ease;
}

.sidebar {
    position: fixed;
    top: 0;
    left: -320px;
    width: 320px;
    height: 100%;
    background: linear-gradient(180deg, #1e3c72 0%, #2a5298 100%);
    color: #fff;
    overflow-y: auto;
    transition: all 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    z-index: 1050;
    box-shadow: 4px 0 20px rgba(0, 0, 0, 0.3);
}

.sidebar::-webkit-scrollbar {
    width: 8px;
}

.sidebar::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.1);
}

.sidebar::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.3);
    border-radius: 10px;
}

.sidebar.active { 
    left: 0;
    box-shadow: 4px 0 30px rgba(0, 0, 0, 0.5);
}

.sidebar-header { 
    padding: 25px 20px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-bottom: 2px solid rgba(255, 255, 255, 0.1);
}

.sidebar-header h3 {
    font-size: 22px;
    font-weight: 700;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    letter-spacing: 0.5px;
}

.sidebar-menu { 
    list-style: none;
    padding: 15px 0;
    margin: 0;
}

.sidebar-menu li { 
    list-style: none;
    padding: 5px 15px;
    margin: 3px 0;
}

.sidebar-menu li a {
    color: #fff;
    text-decoration: none;
    display: flex;
    align-items: center;
    padding: 14px 18px;
    border-radius: 12px;
    transition: all 0.3s ease;
    font-size: 15px;
    font-weight: 500;
    position: relative;
    overflow: hidden;
}

.sidebar-menu li a::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 4px;
    background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
    transform: scaleY(0);
    transition: transform 0.3s ease;
}

.sidebar-menu li a:hover {
    background: rgba(255, 255, 255, 0.15);
    padding-left: 28px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}

.sidebar-menu li a:hover::before {
    transform: scaleY(1);
}

.sidebar-menu li a i {
    margin-right: 12px;
    font-size: 18px;
    width: 25px;
    text-align: center;
}

/* ===== Hamburger ===== */
.hamburger-btn {
    position: fixed;
    top: 10px;
    left: 18px;
    z-index: 1100;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border: none;
    color: #fff;
    padding: 12px 16px;
    font-size: 22px;
    cursor: pointer;
    border-radius: 12px;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
}

.hamburger-btn:hover {
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.4);
}

.hamburger-btn.shifted { 
    left: 335px;
}

/* ===== Overlay ===== */
#overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(3px);
    display: none;
    z-index: 1040;
    transition: all 0.3s ease;
}

#overlay.active { display: block; }

/* ===== Dropdown custom ===== */
.submenu { 
    display: none;
    padding-left: 20px;
    list-style: none;
    margin-top: 5px;
}

.submenu.active { 
    display: block !important;
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.submenu li a {
    padding: 10px 18px;
    font-size: 14px;
    background: rgba(255, 255, 255, 0.05);
    margin: 3px 0;
}

.arrow { 
    float: right;
    transition: transform 0.3s ease;
    font-size: 12px;
}

.arrow::before { 
    font-size: 11px;
}

.dropdown-toggle.active .arrow {
    transform: rotate(180deg);
}

.dropdown-toggle::after {
    display: none;
}

/* ===== Header ===== */
.header {
    position: sticky;
    top: 0;
    left: 0;
    right: 0;
    height: 80px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 30px;
    z-index: 1030;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
    backdrop-filter: blur(10px);
}

.header .title { 
    margin-left: 50px;
    font-size: 24px;
    font-weight: 700;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    letter-spacing: 0.5px;
}

.header .user-info { 
    font-size: 15px;
    display: flex;
    align-items: center;
    gap: 15px;
    font-weight: 500;
}

.header .user-info .username {
    padding: 8px 18px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 20px;
    backdrop-filter: blur(10px);
}

.header .user-info a.logout-btn {
    background: linear-gradient(135deg, #ff416c, #ff4b2b);
    color: #fff;
    padding: 10px 24px;
    border-radius: 25px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(52, 11, 21, 0.4);
    display: inline-block;
}

.header .user-info a.logout-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(255, 65, 108, 0.5);
    filter: brightness(1.1);
}

/* ===== Main Content ===== */
.container-fluid {
    padding: 30px;
}

/* ===== Alert Styles ===== */
.alert {
    border-radius: 12px;
    border: none;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    animation: slideInDown 0.4s ease;
}

@keyframes slideInDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* ===== Card Styles ===== */
.card {
    border: none;
    border-radius: 18px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    background: rgba(255, 255, 255, 0.98);
    backdrop-filter: blur(10px);
    animation: fadeInUp 0.5s ease;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.card-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    border: none;
    border-radius: 18px 18px 0 0 !important;
    padding: 20px 25px;
}

.card-header h5 {
    margin: 0;
    font-weight: 700;
    font-size: 20px;
    text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2);
}

.card-body {
    padding: 25px;
}

/* ===== Button Styles ===== */
.btn {
    border-radius: 10px;
    padding: 8px 20px;
    font-weight: 600;
    transition: all 0.3s ease;
    border: none;
}

.btn-light {
    background: rgba(255, 255, 255, 0.3);
    color: #fff;
    border: 2px solid rgba(255, 255, 255, 0.5);
    backdrop-filter: blur(5px);
}

.btn-light:hover {
    background: rgba(255, 255, 255, 1);
    color: #667eea;
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}

.btn-success {
    background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
    color: #fff;
}

.btn-success:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(17, 153, 142, 0.4);
    filter: brightness(1.1);
}

.btn-warning {
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    color: #fff;
}

.btn-warning:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(245, 87, 108, 0.4);
    filter: brightness(1.1);
}

.btn-danger {
    background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%);
    color: #fff;
}

.btn-danger:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(255, 65, 108, 0.4);
    filter: brightness(1.1);
}

.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
    filter: brightness(1.1);
}

.btn-info {
    background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
    color: #fff;
}

.btn-info:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(79, 172, 254, 0.4);
    filter: brightness(1.1);
}

.btn-action {
    margin: 0 3px;
}

/* ===== Table Styles ===== */
.table-responsive {
    border-radius: 12px;
    overflow-x: auto;
    overflow-y: visible;
    font-size: 0.85rem;
    -webkit-overflow-scrolling: touch;
}

.table-responsive::-webkit-scrollbar {
    height: 10px;
}

.table-responsive::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 10px;
}

.table-responsive::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 10px;
}

.table-responsive::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
}

.table {
    margin: 0;
}

.table thead th {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    font-weight: 600;
    border: none;
    padding: 12px 8px;
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.5px;
}

.table tbody tr {
    transition: all 0.3s ease;
}

.table tbody tr:hover {
    background: rgba(102, 126, 234, 0.1);
    transform: scale(1.005);
}

.table tbody td {
    padding: 10px 8px;
    vertical-align: middle;
    font-size: 0.85rem;
}

/* ===== Badge Styles ===== */
.badge {
    padding: 6px 12px;
    border-radius: 20px;
    font-weight: 600;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.route-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 0.75rem;
    font-weight: 600;
}

.route-from {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
}

.route-to {
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    color: #fff;
}

/* ===== Modal Styles ===== */
.modal-content {
    border: none;
    border-radius: 18px;
    box-shadow: 0 15px 50px rgba(0, 0, 0, 0.3);
}

.modal-header {
    border-radius: 18px 18px 0 0;
    border-bottom: none;
    padding: 20px 25px;
}

.modal-body {
    padding: 25px;
}

.modal-footer {
    border-top: none;
    padding: 15px 25px 20px;
}

.form-label {
    font-weight: 600;
    color: #2a5298;
    margin-bottom: 8px;
    font-size: 0.9rem;
}

.form-control, .form-select {
    border: 2px solid #e0e6ed;
    border-radius: 10px;
    padding: 10px 15px;
    transition: all 0.3s ease;
    font-size: 0.9rem;
}

.form-control:focus, .form-select:focus {
    border-color: #667eea;
    box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
}

/* ===== Select2 Custom ===== */
.select2-container--default .select2-selection--single {
    border: 2px solid #e0e6ed;
    border-radius: 10px;
    height: 42px;
    padding: 6px 15px;
}

.select2-container--default .select2-selection--single:focus {
    border-color: #667eea;
}

/* ===== DataTables Custom ===== */
.dataTables_wrapper .dataTables_length select,
.dataTables_wrapper .dataTables_filter input {
    border: 2px solid #e0e6ed;
    border-radius: 8px;
    padding: 6px 12px;
}

.dataTables_wrapper .dataTables_paginate .paginate_button.current {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    border-color: #667eea !important;
    color: white !important;
    border-radius: 8px;
}

.dataTables_wrapper .dataTables_paginate .paginate_button:hover {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    border-color: #667eea !important;
    color: white !important;
}

/* ===== Responsive ===== */
@media (max-width: 768px) {
    .header .title {
        font-size: 18px;
        margin-left: 20px;
    }
    
    .hamburger-btn.shifted {
        left: 295px;
    }
    
    .sidebar {
        width: 280px;
        left: -280px;
    }
    
    .table-responsive {
        font-size: 0.75rem;
    }
}
</style>
</head>

<body>

<button class="hamburger-btn" id="hamburgerBtn">
    <i class="fas fa-bars"></i>
</button>

<div id="overlay"></div>

<div class="header">
    <div class="title">Koreksi Tonase</div>
    <div class="user-info">
        <span class="username"><i class="fas fa-user-circle"></i> <?= htmlspecialchars($username) ?></span>
        <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</div>

<div class="container-fluid main-content">

    <div class="card mb-3">
        <div class="card-header bg-warning text-dark d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-edit"></i> Input Koreksi Tonase</h5>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#summaryModal">
                <i class="bi bi-eye"></i> Lihat Koreksi
            </button>
        </div>
        <div class="card-body">
            <div class="alert alert-info">
                <i class="bi bi-info-circle"></i> Halaman ini menampilkan total tonase dari Surat Jalan, dikelompokkan berdasarkan Tanggal, Shift, dan Warehouse.
                <br>
                <i class="bi bi-pencil-square"></i> Masukkan nilai tonase koreksi di kolom "PETROPORT (Koreksi)" dan klik "Simpan Koreksi" di bagian bawah.
            </div>

            <form method="POST" id="formKoreksi">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover table-striped table-sm" id="koreksiTable">
                        <thead class="table-dark">
                            <tr>
                                <th>BARANG</th>
                                <th>KAPAL</th>
                                <th>TANGGAL</th>
                                <th>SHIFT</th>
                                <th>WAREHOUSE</th>
                                <th>REALISASI</th>
                                <th>PETROPORT</th>
                                <th>SELISIH</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($groupedResult->num_rows > 0): ?>
                                <?php while($row = $groupedResult->fetch_assoc()): ?>
                                    <?php
                                        $tonase_koreksi = $row['tonase_koreksi'] !== null ? floatval($row['tonase_koreksi']) : 0;
                                        $total_tonase = floatval($row['total_tonase']);
                                        $selisih = $total_tonase - $tonase_koreksi;
                                        if ($row['tonase_koreksi'] === null) {
                                            $selisih = 0;
                                        }
                                    ?>
                                    <tr class="data-row" data-warehouse="<?= htmlspecialchars($row['nama_warehouse']) ?>" data-warehouse-id="<?= $row['warehouse_id'] ?>">
                                        <input type="hidden" name="tanggal[]" value="<?= $row['tanggal'] ?>">
                                        <input type="hidden" name="shift[]" value="<?= $row['shift'] ?>">
                                        <input type="hidden" name="warehouse_id[]" value="<?= $row['warehouse_id'] ?>">
                                        <input type="hidden" name="barang_id[]" value="<?= $row['barang_id'] ?>">
                                        <input type="hidden" name="kapal_id[]" value="<?= $row['kapal_id'] ?>">
                                        
                                        <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                                        <td><?= htmlspecialchars($row['nama_kapal']) ?></td>
                                        <td><?= date('d/m/Y', strtotime($row['tanggal'])) ?></td>
                                        <td class="text-center"><?= $row['shift'] ?></td>
                                        <td><?= htmlspecialchars($row['nama_warehouse']) ?></td>
                                        
                                        <td class="text-end">
                                            <input type="number" class="form-control-plaintext text-end total-tonase" 
                                                   value="<?= number_format($total_tonase, 3, '.', '') ?>" readonly>
                                        </td>
                                        
                                        <td>
                                            <input type="number" name="tonase_koreksi[]" class="form-control tonase-koreksi" 
                                                   step="0.001" 
                                                   value="<?= $row['tonase_koreksi'] !== null ? number_format($row['tonase_koreksi'], 3, '.', '') : '' ?>" 
                                                   placeholder="0.000">
                                        </td>
                                        
                                        <td class="text-end">
                                            <input type="number" class="form-control-plaintext text-end selisih" 
                                                   value="<?= number_format($selisih, 3, '.', '') ?>" readonly>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center">Belum ada data surat jalan untuk dikoreksi.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr class="total-row">
                                <td colspan="5" class="text-center"><strong>TOTAL</strong></td>
                                <td class="text-end"><strong id="totalRealisasi">0.000</strong></td>
                                <td class="text-end"><strong id="totalPetroport">-</strong></td>
                                <td class="text-end"><strong id="totalSelisih">-</strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <div class="mt-3">
                    <button type="submit" name="submit_koreksi" class="btn btn-success">
                        <i class="bi bi-save"></i> Simpan Koreksi
                    </button>
                    <a href="koreksi.php" class="btn btn-secondary">
                        <i class="bi bi-arrow-counterclockwise"></i> Reset
                    </a>
                </div>
                <div class="mt-3">
    <button type="submit" name="submit_koreksi" class="btn btn-success">
        <i class="bi bi-save"></i> Simpan Koreksi
    </button>
    <a href="koreksi.php" class="btn btn-secondary">
        <i class="bi bi-arrow-counterclockwise"></i> Reset
    </a>

    <button type="button" id="exportExcelBtn" class="btn btn-info">
        <i class="bi bi-file-earmark-excel"></i> Export Excel
    </button>
    <button type="button" id="cetakPdfBtn" class="btn btn-danger">
        <i class="bi bi-file-earmark-pdf"></i> Cetak PDF
    </button>
    </div>
            </form>
        </div>
    </div>

</div>

<!-- Modal Summary -->
<div class="modal fade" id="summaryModal" tabindex="-1" aria-labelledby="summaryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg-custom">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title" id="summaryModalLabel"><i class="bi bi-bar-chart-fill"></i> Ringkasan Koreksi Tonase</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="card summary-card mb-3">
                    <div class="card-body">
                        <h6 class="card-title mb-3"><i class="bi bi-building"></i> Total Per Warehouse</h6>
                        <div class="table-responsive">
                            <table class="table table-bordered table-sm summary-table">
                                <thead>
                                    <tr>
                                        <th>WAREHOUSE</th>
                                        <th class="text-end">REALISASI</th>
                                        <th class="text-end">PETROPORT</th>
                                        <th class="text-end">SELISIH</th>
                                    </tr>
                                </thead>
                                <tbody id="warehouseSummaryBody">
                                    <!-- Diisi oleh JavaScript -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="card summary-card">
                    <div class="card-body">
                        <h6 class="card-title mb-3"><i class="bi bi-calculator"></i> Total Keseluruhan</h6>
                        <div class="table-responsive">
                            <table class="table table-bordered table-sm summary-table">
                                <thead>
                                    <tr>
                                        <th>TOTAL</th>
                                        <th class="text-end">REALISASI</th>
                                        <th class="text-end">PETROPORT</th>
                                        <th class="text-end">SELISIH</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="total-row">
                                        <td><strong>GRAND TOTAL</strong></td>
                                        <td class="text-end"><strong id="modalTotalRealisasi">0.000</strong></td>
                                        <td class="text-end"><strong id="modalTotalPetroport">-</strong></td>
                                        <td class="text-end"><strong id="modalTotalSelisih">-</strong></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Hamburger toggle
const hamburger = document.getElementById('hamburgerBtn');
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');

function openSidebar(){ 
    sidebar.classList.add('active'); 
    overlay.classList.add('active'); 
    hamburger.classList.add('shifted'); 
}

function closeSidebar(){ 
    sidebar.classList.remove('active'); 
    overlay.classList.remove('active'); 
    hamburger.classList.remove('shifted'); 
}

hamburger.addEventListener('click',()=>{ 
    sidebar.classList.contains('active') ? closeSidebar() : openSidebar(); 
});

overlay.addEventListener('click', closeSidebar);

// Dropdown toggle
document.querySelectorAll('.dropdown-toggle').forEach(toggle=>{
    toggle.addEventListener('click', function(e){
        e.preventDefault();
        this.classList.toggle('active');
        const submenu = this.nextElementSibling;
        if(submenu){ submenu.classList.toggle('active'); }
    });
});

// --- LOGIKA KALKULASI SELISIH DAN TOTAL ---

function calculateSelisih(inputElement) {
    const row = inputElement.closest('tr');
    if (!row) return;
    
    const totalTonaseInput = row.querySelector('.total-tonase');
    const selisihInput = row.querySelector('.selisih');
    
    const totalTonase = parseFloat(totalTonaseInput.value) || 0;
    const tonaseKoreksi = parseFloat(inputElement.value) || 0;
    
    let selisih = 0;
    
    if (inputElement.value !== '') {
        selisih = totalTonase - tonaseKoreksi;
    }

    selisihInput.value = selisih.toFixed(3);
    
    selisihInput.classList.remove('text-danger', 'text-success');
    if (selisih > 0) {
        selisihInput.classList.add('text-success');
    } else if (selisih < 0) {
        selisihInput.classList.add('text-danger');
    }
    
    updateTotals();
}

function updateTotals() {
    let totalRealisasi = 0;
    let totalPetroport = 0;
    let totalSelisih = 0;
    let hasPetroport = false;
    
    const dataRows = document.querySelectorAll('.data-row');
    
    dataRows.forEach(row => {
        const realisasiInput = row.querySelector('.total-tonase');
        const petroportInput = row.querySelector('.tonase-koreksi');
        const selisihInput = row.querySelector('.selisih');
        
        const realisasi = parseFloat(realisasiInput.value) || 0;
        const petroport = parseFloat(petroportInput.value) || 0;
        const selisih = parseFloat(selisihInput.value) || 0;
        
        totalRealisasi += realisasi;
        
        if (petroportInput.value !== '') {
            totalPetroport += petroport;
            totalSelisih += selisih;
            hasPetroport = true;
        }
    });
    
    document.getElementById('totalRealisasi').textContent = totalRealisasi.toFixed(3);
    
    if (hasPetroport) {
        document.getElementById('totalPetroport').textContent = totalPetroport.toFixed(3);
        
        const totalSelisihElement = document.getElementById('totalSelisih');
        totalSelisihElement.textContent = '(' + Math.abs(totalSelisih).toFixed(3) + ')';
        
        totalSelisihElement.classList.remove('text-danger', 'text-success');
        if (totalSelisih > 0) {
            totalSelisihElement.classList.add('text-success');
        } else if (totalSelisih < 0) {
            totalSelisihElement.classList.add('text-danger');
        }
    } else {
        document.getElementById('totalPetroport').textContent = '-';
        document.getElementById('totalSelisih').textContent = '-';
    }
}

function updateModalSummary() {
    const warehouseData = {};
    let grandTotalRealisasi = 0;
    let grandTotalPetroport = 0;
    let grandTotalSelisih = 0;
    let hasAnyPetroport = false;
    
    const dataRows = document.querySelectorAll('.data-row');
    
    dataRows.forEach(row => {
        const warehouseName = row.dataset.warehouse;
        const realisasiInput = row.querySelector('.total-tonase');
        const petroportInput = row.querySelector('.tonase-koreksi');
        const selisihInput = row.querySelector('.selisih');
        
        const realisasi = parseFloat(realisasiInput.value) || 0;
        const petroport = parseFloat(petroportInput.value) || 0;
        const selisih = parseFloat(selisihInput.value) || 0;
        
        if (!warehouseData[warehouseName]) {
            warehouseData[warehouseName] = {
                realisasi: 0,
                petroport: 0,
                selisih: 0,
                hasPetroport: false
            };
        }
        
        warehouseData[warehouseName].realisasi += realisasi;
        grandTotalRealisasi += realisasi;
        
        if (petroportInput.value !== '') {
            warehouseData[warehouseName].petroport += petroport;
            warehouseData[warehouseName].selisih += selisih;
            warehouseData[warehouseName].hasPetroport = true;
            
            grandTotalPetroport += petroport;
            grandTotalSelisih += selisih;
            hasAnyPetroport = true;
        }
    });
    
    // Update warehouse summary table
    const summaryBody = document.getElementById('warehouseSummaryBody');
    summaryBody.innerHTML = '';
    
    for (const [warehouse, data] of Object.entries(warehouseData)) {
        const row = document.createElement('tr');
        row.className = 'warehouse-total-row';
        
        let petroportDisplay = '-';
        let selisihDisplay = '-';
        let selisihClass = '';
        
        if (data.hasPetroport) {
            petroportDisplay = data.petroport.toFixed(3);
            selisihDisplay = '(' + Math.abs(data.selisih).toFixed(3) + ')';
            selisihClass = data.selisih > 0 ? 'text-success' : (data.selisih < 0 ? 'text-danger' : '');
        }
        
        row.innerHTML = `
            <td><strong>${warehouse}</strong></td>
            <td class="text-end">${data.realisasi.toFixed(3)}</td>
            <td class="text-end">${petroportDisplay}</td>
            <td class="text-end ${selisihClass}">${selisihDisplay}</td>
        `;
        
        summaryBody.appendChild(row);
    }
    
    // Update grand total
    document.getElementById('modalTotalRealisasi').textContent = grandTotalRealisasi.toFixed(3);
    
    if (hasAnyPetroport) {
        document.getElementById('modalTotalPetroport').textContent = grandTotalPetroport.toFixed(3);
        
        const modalTotalSelisihElement = document.getElementById('modalTotalSelisih');
        modalTotalSelisihElement.textContent = '(' + Math.abs(grandTotalSelisih).toFixed(3) + ')';
        
        modalTotalSelisihElement.classList.remove('text-danger', 'text-success');
        if (grandTotalSelisih > 0) {
            modalTotalSelisihElement.classList.add('text-success');
        } else if (grandTotalSelisih < 0) {
            modalTotalSelisihElement.classList.add('text-danger');
        }
    } else {
        document.getElementById('modalTotalPetroport').textContent = '-';
        document.getElementById('modalTotalSelisih').textContent = '-';
    }
}

// Event listener untuk modal
document.getElementById('summaryModal').addEventListener('show.bs.modal', function() {
    updateModalSummary();
});

// Ambil semua input koreksi
const koreksiInputs = document.querySelectorAll('.tonase-koreksi');

koreksiInputs.forEach(input => {
    calculateSelisih(input);
    
    input.addEventListener('input', function() {
        calculateSelisih(this);
    });
});

updateTotals();
</script>

</body>
</html>